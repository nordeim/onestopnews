## Phase 1: ANALYZE — Original Mockup vs. v3.1 PRD Requirements

I've read the full original mockup. It's a strong "Editorial Dispatch" foundation — but it predates every correction from our review cycles. Here's the systematic gap analysis:

---

### Gap Matrix: Original → v3.1 Target

| # | Aspect | Original Mockup | v3.1 PRD Requirement | Severity |
|---|---|---|---|---|
| 1 | **Editorial typeface** | `Instrument Serif` | **`Newsreader`** (variable, optical size) | ★★★★★ |
| 2 | **UI typeface** | `Space Grotesk` | **`Instrument Sans`** (warmer, less saturated) | ★★★★★ |
| 3 | **Mono typeface** | `JetBrains Mono` | **`Commit Mono`** (reading-optimized) | ★★★★☆ |
| 4 | **Breaking accent** | `signal-amber` (#B45309) | **`dispatch-ember`** (#c7513f, coral-red) | ★★★★★ |
| 5 | **Color naming** | `signal-*` namespace | **`dispatch-*`** namespace | ★★★☆☆ |
| 6 | **AI model name** | "Claude 3.5 Haiku" | **"Claude 4.5 Haiku"** | ★★★★★ |
| 7 | **AI disclosure** | Basic accordion with model/tokens | **Full AI Nutrition Label** + EU AI Act statement | ★★★★★ |
| 8 | **Machine-readable provenance** | None | **`<meta name="ai-provenance">`** in `<head>` | ★★★★★ |
| 9 | **EU AI Act compliance** | Not mentioned | **Referenced throughout** | ★★★★☆ |
| 10 | **Story grid layout** | Asymmetric `col-span-7/5/4` | **CSS Subgrid** (`grid-rows-subgrid`) | ★★★★★ |
| 11 | **Push notifications** | Not featured | **New section** — AI-summarised push alerts | ★★★★☆ |
| 12 | **Reading mode** | Not featured | **Mentioned** as feature | ★★★☆☆ |
| 13 | **Trending section** | Not featured | **"Trending among readers"** section | ★★★☆☆ |
| 14 | **View Transitions** | Not referenced | **Native React 19.2 `<ViewTransition>`** | ★★★☆☆ |
| 15 | **"AI Brief" badge** | Not present on cards | **Present** on cards with summaries | ★★★★☆ |
| 16 | **Font loading** | Google Fonts CDN | Same CDN but different font families | ★★★★★ |

---

### Critical Design-Direction Shifts

**Shift 1: Typographic Identity — From "Warm Modern" to "Editorial Dispatch"**
The original uses Instrument Serif (which has a literary, bookish character) paired with Space Grotesk (which is geometric, tech-forward). The v3.1 pairing — Newsreader + Instrument Sans — is more deliberately editorial. Newsreader was literally designed for news text; its variable optical size axis means headlines render with higher contrast at display sizes. Instrument Sans is warmer than Space Grotesk, with a humanist undercurrent that feels less "startup" and more "publication."

**Shift 2: Color Psychology — From "Warning" to "Urgency"**
The original's amber accent (#B45309) for breaking news reads as "caution/warning" in UI convention — think traffic lights, error states, alert banners. Coral-red (#c7513f) conveys urgency without alarm fatigue. It's the difference between "Something is wrong" and "Something important is happening." This matters enormously for a news product where the accent color appears on every breaking-news badge.

**Shift 3: AI Trust Architecture — From "Transparency" to "Nutrition Label"**
The original has a basic accordion showing model, tokens, generation date. The v3.1 Nutrition Label is a substantially richer disclosure: it includes a "What the AI did" natural-language statement, source coverage percentage, EU AI Act compliance language, and a structured citations list. It's the difference between "we're telling you we used AI" and "we're giving you everything you need to verify this yourself."

**Shift 4: Structural Integrity — From "Asymmetric Grid" to "Subgrid Alignment"**
The original's asymmetric card grid (col-span-7, col-span-5, col-span-4) is visually interesting but structurally fragile — metadata lines don't align across cards. Subgrid guarantees that every card's internal rows (headline, excerpt, metadata) sit on the same horizontal tracks, creating the "wire service precision" that defines Editorial Dispatch.

---

## Phase 2: PLAN — Re-Imagined Mockup Architecture

### 2.1 Section Map (12 Sections, Re-ordered & Enhanced)

| # | Section | Original | v3.1 Change |
|---|---|---|---|
| 1 | **Wire Ticker** | Yes | Updated: ember accent, Commit Mono, Claude 4.5 Haiku reference |
| 2 | **Masthead** | Yes | Updated: Newsreader wordmark, Instrument Sans tagline |
| 3 | **Category Navigation** | Yes | Updated: dispatch-* accents, Instrument Sans labels, "AI Brief" counts |
| 4 | **Lead Story** | Yes | Updated: Newsreader headline, ember breaking badge, AI Nutrition Label preview |
| 5 | **Trending Bar** | **No** | **New:** horizontal scroll of trending stories with reader counts |
| 6 | **Story Grid (Subgrid)** | Yes (asymmetric) | **Rewritten:** CSS Subgrid with `grid-rows-subgrid`, Commit Mono metadata, "AI Brief" badges |
| 7 | **Concept Introduction** | Yes | Updated: Newsreader headline, Instrument Sans body |
| 8 | **AI Summary Demo + Nutrition Label** | Yes (basic) | **Major rewrite:** Full Nutrition Label, EU AI Act compliance, Claude 4.5 Haiku |
| 9 | **Push Notification Showcase** | **No** | **New:** Mock push alert with AI summary, device frame |
| 10 | **How It Works** | Yes | Updated: typography, ember accents |
| 11 | **Search & Performance** | Yes | Updated: typography, metric styling |
| 12 | **Trust Commitments (Ink Section)** | Yes | Updated: "AI Nutrition Label" naming, EU AI Act reference, ember for Disclosure |
| 13 | **Early Access CTA** | Yes | Updated: typography |
| 14 | **Footer** | Yes | Updated: Claude 4.5 Haiku, v1.0.0-beta, "Built With" stack |

### 2.2 Typography Implementation

```html
<!-- Font loading: Newsreader + Instrument Sans + Commit Mono -->
<link href="https://fonts.googleapis.com/css2?family=Newsreader:ital,opsz,wght@0,6..72,200..800;1,6..72,200..800&family=Instrument+Sans:ital,wght@0,400..700;1,400..700&family=Commit+Mono:ital@0;1&display=swap" rel="stylesheet">
```

Tailwind config font families:
```javascript
fontFamily: {
    editorial: ['"Newsreader"', 'Georgia', 'serif'],
    sans:      ['"Instrument Sans"', 'system-ui', 'sans-serif'],
    mono:      ['"Commit Mono"', '"JetBrains Mono"', 'monospace'],
}
```

### 2.3 Color Token Transformation

| Original Token | Original Value | v3.1 Token | v3.1 Value |
|---|---|---|---|
| `signal-amber` | #B45309 | `dispatch-ember` | #c7513f |
| `signal-amber-light` | #FEF3C7 | `dispatch-ember-light` | #fce4dc |
| `signal-sage` | #3D6B4F | `dispatch-sage` | #6b8f71 |
| `signal-slate` | #4A5568 | `dispatch-slate` | #5a6b7a |
| `signal-clay` | #9C4221 | `dispatch-clay` | #8b6d5a |
| `signal-violet` | #5B4C9A | `dispatch-violet` | #7a6b8f |
| `signal-rose` | #9F1239 | `dispatch-ember` (for live indicator) | #c7513f |

### 2.4 New Sections: Detailed Specification

**Trending Bar (Section 5 — NEW):**
A horizontal scroll strip between the lead story and the story grid. Shows 5-8 stories with reader view counts. Uses Commit Mono for numbers, Instrument Sans for titles.

**Push Notification Showcase (Section 9 — NEW):**
A visual demo of the AI-summarised push notification. Phone-frame mockup showing a notification card with: app icon, "OneStopNews" header, AI-summarised 1-sentence alert, and the source article reference. Surrounded by explanation copy about the feature.

**AI Summary Demo — Nutrition Label (Section 8 — MAJOR REWRITE):**
The existing tabbed demo panel gets restructured with:
1. The "AI Nutrition Label" header with model + timestamp
2. Summary text with inline citations
3. Key Points list
4. **NEW:** "What the AI did" statement
5. **NEW:** EU AI Act Article 50 compliance badge
6. Source citations
7. Confidence bar
8. "Verify with Original Source" escape hatch

### 2.5 CSS Subgrid Implementation Strategy

The story grid section will use this pattern:

```css
/* Parent defines rows via implicit grid */
.story-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 1.5rem;
}

/* Each card spans 3 rows and uses subgrid */
.story-card-subgrid {
    display: grid;
    grid-row: span 3;
    grid-template-rows: subgrid;
    gap: 0.75rem;
}
```

This forces headline, excerpt, and metadata of every card in a row to share the same row heights — perfect horizontal alignment without JS.

### 2.6 JavaScript Enhancements

The original's JS is solid. I'll enhance:
1. **Intersection Observer** for Nutrition Label animation (confidence bar fill)
2. **Tab switching** — preserved, updated for new panel structure
3. **Accordion** — preserved, updated for Nutrition Label disclosure
4. **Category nav** — preserved, updated for dispatch-* color classes
5. **Sort buttons** — preserved
6. **Ticker** — preserved, updated content with Claude 4.5 Haiku mention
7. **NEW:** Trending bar auto-scroll pause on hover
8. **NEW:** Push notification demo interaction (tap to expand)

---

## Phase 3: VALIDATE — Confirmation Checkpoint

Here's a summary of what the re-imagined mockup will deliver:

**Will change:**
- All three typefaces → Newsreader + Instrument Sans + Commit Mono
- All accent colors → dispatch-* namespace with ember coral-red
- AI model name → Claude 4.5 Haiku
- AI disclosure → full Nutrition Label + EU AI Act compliance
- Story grid → CSS Subgrid alignment
- `<head>` → machine-readable provenance meta tag
- Story cards → "AI Brief" badges added
- 2 new sections: Trending Bar, Push Notification Showcase

**Will preserve:**
- 12-column editorial layout
- Wire ticker (with updated content)
- Masthead wordmark structure
- Sticky category navigation pattern
- Lead story + image layout
- Concept introduction messaging
- How It Works 3-step flow
- Search & Performance metrics
- Five Trust Commitments (with updated labeling)
- Early Access CTA form
- Footer structure
- Scroll reveal animations
- `prefers-reduced-motion` respect
- All ARIA attributes and accessibility patterns

**One question before I write the full HTML:**

The original mockup is ~550 lines of HTML + CSS + JS. The re-imagined version will be longer (estimated ~700 lines) due to the Nutrition Label expansion, Subgrid implementation, and two new sections. Shall I:

---

I'm building the complete, production-grade replacement. Every typeface, every color token, every component aligned to the v3.1 PRD. 

---

## Executive Summary

This is a complete, self-contained HTML mockup that replaces the original with the definitive v3.1 "Editorial Dispatch" design system:

- **Typography:** Newsreader (editorial) + Instrument Sans (UI) + Commit Mono (monospace)
- **Accent:** `dispatch-ember` (#c7513f) coral-red for breaking news — not amber
- **Color namespace:** `dispatch-*` replacing `signal-*`
- **AI model:** Claude 4.5 Haiku (corrected from 3.5)
- **AI disclosure:** Full AI Nutrition Label with EU AI Act Article 50 compliance
- **Machine-readable provenance:** `<meta name="ai-provenance">` in `<head>`
- **Story grid:** CSS Subgrid (`grid-template-rows: subgrid`) for perfect metadata alignment
- **New sections:** Trending Bar + Push Notification Showcase
- **"AI Brief" badges** on cards with AI summaries

---

## Complete HTML Mockup

```html
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OneStopNews — Your Briefing Room</title>
    <meta name="description" content="Topic-first news aggregation with source-cited AI summaries. Every story, organized by what it's about — not who published it.">
    
    <!-- Machine-Readable AI Provenance (EU AI Act Article 50) -->
    <meta name="ai-provenance" content="provider:claude-4.5-haiku;compliance:eu-ai-act-art50;standard:c2pa">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Newsreader:ital,opsz,wght@0,6..72,200..800;1,6..72,200..800&family=Instrument+Sans:ital,wght@0,400..700;1,400..700&family=Commit+Mono:ital@0;1&display=swap" rel="stylesheet">

    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        /* ── Ink & Paper Design System ── */
                        /* Warmer ink values — letterpress black, not pure #000 */
                        ink: {
                            900: '#1a1a18',  /* letterpress black — headlines, dark backgrounds */
                            700: '#2d2d2a',  /* secondary headings */
                            600: '#3d3d3a',  /* body text */
                            500: '#52524e',  /* supporting text */
                            400: '#73736e',  /* muted */
                            300: '#8a8a83',  /* metadata */
                            200: '#b8b8b0',  /* borders on light */
                            100: '#d4d4cc',  /* subtle borders on light */
                        },
                        paper: {
                            50:  '#fafaf8',  /* newsprint off-white — page background */
                            100: '#f2f2ee',  /* card surfaces */
                            200: '#e8e8e0',  /* borders, dividers */
                            300: '#d8d8ce',  /* heavy dividers */
                        },
                        /* ── Dispatch Accent System ── */
                        /* Coral-red for breaking — urgency without "warning" connotation */
                        dispatch: {
                            ember:      '#c7513f',  /* Breaking / Top Stories */
                            'ember-light': '#fce4dc',
                            sage:       '#6b8f71',  /* Finance */
                            'sage-light': '#e8f5e9',
                            slate:      '#5a6b7a',  /* Tech / Global */
                            'slate-light': '#e8edf2',
                            clay:       '#8b6d5a',  /* Politics / Local */
                            'clay-light': '#f5ede6',
                            violet:     '#7a6b8f',  /* Culture */
                            'violet-light': '#f0edf7',
                        },
                    },
                    fontFamily: {
                        editorial: ['"Newsreader"', 'Georgia', 'serif'],
                        sans:      ['"Instrument Sans"', 'system-ui', 'sans-serif'],
                        mono:      ['"Commit Mono"', '"JetBrains Mono"', 'monospace'],
                    },
                    maxWidth: {
                        dispatch: '1440px',
                    },
                    boxShadow: {
                        'card-hover': '0 4px 12px -2px rgba(26,26,24,0.08), 0 2px 6px -2px rgba(26,26,24,0.04)',
                        'panel': '0 1px 3px rgba(26,26,24,0.06), 0 1px 2px rgba(26,26,24,0.04)',
                    },
                }
            }
        }
    </script>

    <style>
        /* ═══════════════════════════════════════════════════════════════ */
        /* BASE & SELECTION                                                */
        /* ═══════════════════════════════════════════════════════════════ */
        * { -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; }
        ::selection { background: #f0edf7; color: #1a1a18; }

        /* ═══════════════════════════════════════════════════════════════ */
        /* TICKER ANIMATION                                                */
        /* ═══════════════════════════════════════════════════════════════ */
        @keyframes ticker-scroll {
            0%   { transform: translateX(0); }
            100% { transform: translateX(-50%); }
        }
        .ticker-track { animation: ticker-scroll 80s linear infinite; }
        .ticker-track:hover { animation-play-state: paused; }

        /* ═══════════════════════════════════════════════════════════════ */
        /* LIVE PULSE                                                      */
        /* ═══════════════════════════════════════════════════════════════ */
        @keyframes pulse-dot {
            0%, 100% { opacity: 1; }
            50%      { opacity: .3; }
        }
        .pulse-dot { animation: pulse-dot 2s ease-in-out infinite; }

        /* ═══════════════════════════════════════════════════════════════ */
        /* TYPOGRAPHIC UTILITIES                                           */
        /* ═══════════════════════════════════════════════════════════════ */
        .cat-label { font-variant: all-small-caps; letter-spacing: .1em; }
        .cat-label-wide { font-variant: all-small-caps; letter-spacing: .2em; }

        /* ═══════════════════════════════════════════════════════════════ */
        /* EDITORIAL RULES                                                 */
        /* ═══════════════════════════════════════════════════════════════ */
        .dispatch-rule       { border: none; border-top: 1px solid #d8d8ce; margin: 0; }
        .dispatch-rule-thick { border: none; border-top: 2.5px solid #1a1a18; margin: 0; }
        .dispatch-rule-ink   { border: none; border-top: 1px solid rgba(255,255,255,0.12); margin: 0; }

        /* ═══════════════════════════════════════════════════════════════ */
        /* STORY CARDS                                                     */
        /* ═══════════════════════════════════════════════════════════════ */
        .story-card {
            transition: transform 180ms cubic-bezier(.4,0,.2,1),
                        background-color 180ms ease,
                        box-shadow 180ms cubic-bezier(.4,0,.2,1);
        }
        .story-card:hover {
            background-color: #f2f2ee;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px -2px rgba(26,26,24,0.08), 0 2px 6px -2px rgba(26,26,24,0.04);
        }

        /* ═══════════════════════════════════════════════════════════════ */
        /* CSS GRID SUBGRID — The Structural Mandate                       */
        /* Forces headline, excerpt, metadata to align across all cards     */
        /* in a visual row. No JS. No fixed heights. Pure CSS.             */
        /* ═══════════════════════════════════════════════════════════════ */
        .subgrid-parent {
            display: grid;
            grid-template-columns: repeat(1, 1fr);
            gap: 0 2rem;
            grid-auto-rows: auto;
        }
        @media (min-width: 768px) {
            .subgrid-parent { grid-template-columns: repeat(2, 1fr); }
        }
        @media (min-width: 1024px) {
            .subgrid-parent { grid-template-columns: repeat(3, 1fr); }
        }
        .subgrid-card {
            display: grid;
            grid-row: span 3;
            grid-template-rows: subgrid;
            gap: 0.75rem;
            margin-bottom: 2.5rem;
            border-bottom: 1px solid #d4d4cc;
            padding-bottom: 1.5rem;
            transition: background-color 300ms ease;
            cursor: pointer;
            position: relative;
        }
        .subgrid-card:hover {
            background-color: #f2f2ee;
        }

        /* ═══════════════════════════════════════════════════════════════ */
        /* CITATION REFERENCES                                             */
        /* ═══════════════════════════════════════════════════════════════ */
        .citation-ref {
            border-bottom: 1px dashed #7a6b8f;
            cursor: pointer;
            transition: background 150ms ease;
        }
        .citation-ref:hover { background-color: #f0edf7; }

        /* ═══════════════════════════════════════════════════════════════ */
        /* TAB BUTTONS                                                     */
        /* ═══════════════════════════════════════════════════════════════ */
        .tab-btn {
            position: relative;
            transition: color 150ms ease;
        }
        .tab-btn::after {
            content: '';
            position: absolute;
            bottom: -4px;
            left: 0;
            width: 0;
            height: 2px;
            background: #1a1a18;
            transition: width 200ms cubic-bezier(.4,0,.2,1);
        }
        .tab-btn.active::after { width: 100%; }
        .tab-btn.active { color: #1a1a18; }

        /* ═══════════════════════════════════════════════════════════════ */
        /* CATEGORY NAV                                                    */
        /* ═══════════════════════════════════════════════════════════════ */
        .category-nav { scrollbar-width: none; -ms-overflow-style: none; }
        .category-nav::-webkit-scrollbar { display: none; }

        /* ═══════════════════════════════════════════════════════════════ */
        /* CONFIDENCE BAR                                                  */
        /* ═══════════════════════════════════════════════════════════════ */
        .confidence-bar {
            height: 3px;
            background: #e8e8e0;
            border-radius: 2px;
            overflow: hidden;
        }
        .confidence-fill {
            height: 100%;
            background: #6b8f71;
            border-radius: 2px;
            width: 0;
            transition: width 800ms cubic-bezier(.4,0,.2,1);
        }
        .confidence-fill.animate { width: 87%; }

        /* ═══════════════════════════════════════════════════════════════ */
        /* FOCUS STATES                                                    */
        /* ═══════════════════════════════════════════════════════════════ */
        :focus-visible {
            outline: 2px solid #7a6b8f;
            outline-offset: 2px;
            border-radius: 2px;
        }

        /* ═══════════════════════════════════════════════════════════════ */
        /* ACCORDION                                                       */
        /* ═══════════════════════════════════════════════════════════════ */
        .accordion-content {
            max-height: 0;
            overflow: hidden;
            transition: max-height 300ms cubic-bezier(.4,0,.2,1);
        }
        .accordion-content.open { max-height: 600px; }

        /* ═══════════════════════════════════════════════════════════════ */
        /* SCROLL REVEAL ANIMATIONS                                        */
        /* ═══════════════════════════════════════════════════════════════ */
        .reveal {
            opacity: 0;
            transform: translateY(20px);
            transition: opacity 600ms cubic-bezier(.4,0,.2,1),
                        transform 600ms cubic-bezier(.4,0,.2,1);
        }
        .reveal.visible {
            opacity: 1;
            transform: translateY(0);
        }
        .reveal-delay-1 { transition-delay: 50ms; }
        .reveal-delay-2 { transition-delay: 100ms; }
        .reveal-delay-3 { transition-delay: 150ms; }
        .reveal-delay-4 { transition-delay: 200ms; }
        .reveal-delay-5 { transition-delay: 250ms; }

        /* ═══════════════════════════════════════════════════════════════ */
        /* FEATURE CHECK LIST (Green checkmarks)                           */
        /* ═══════════════════════════════════════════════════════════════ */
        .feature-check::before {
            content: '\2713';
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background: #6b8f71;
            color: #fff;
            font-size: 11px;
            font-weight: 700;
            margin-right: 10px;
            flex-shrink: 0;
        }

        /* ═══════════════════════════════════════════════════════════════ */
        /* COMMITMENT NUMBERS (Watermark numerals in Trust section)        */
        /* ═══════════════════════════════════════════════════════════════ */
        .commitment-number {
            font-family: 'Newsreader', Georgia, serif;
            font-size: 3.5rem;
            line-height: 1;
            opacity: 0.15;
            position: absolute;
            top: -8px;
            right: 16px;
        }

        /* ═══════════════════════════════════════════════════════════════ */
        /* PERFORMANCE METRIC                                              */
        /* ═══════════════════════════════════════════════════════════════ */
        .metric-value {
            font-variant-numeric: tabular-nums;
        }

        /* ═══════════════════════════════════════════════════════════════ */
        /* TRENDING BAR SCROLL                                             */
        /* ═══════════════════════════════════════════════════════════════ */
        .trending-scroll {
            scrollbar-width: none;
            -ms-overflow-style: none;
            scroll-snap-type: x mandatory;
        }
        .trending-scroll::-webkit-scrollbar { display: none; }
        .trending-scroll > * { scroll-snap-align: start; }

        /* ═══════════════════════════════════════════════════════════════ */
        /* PUSH NOTIFICATION DEMO                                          */
        /* ═══════════════════════════════════════════════════════════════ */
        .push-demo-phone {
            background: #1a1a18;
            border-radius: 2.5rem;
            padding: 1rem;
            box-shadow: 0 20px 60px -12px rgba(26,26,24,0.3);
        }
        .push-demo-screen {
            background: #fafaf8;
            border-radius: 1.75rem;
            overflow: hidden;
        }
        .push-notif-card {
            background: #fff;
            border-radius: 1rem;
            box-shadow: 0 2px 12px rgba(0,0,0,0.08);
            animation: notif-in 400ms cubic-bezier(.4,0,.2,1);
        }
        @keyframes notif-in {
            from { opacity: 0; transform: translateY(-16px); }
            to   { opacity: 1; transform: translateY(0); }
        }
        @keyframes notif-badge-pulse {
            0%, 100% { transform: scale(1); }
            50%      { transform: scale(1.12); }
        }

        /* ═══════════════════════════════════════════════════════════════ */
        /* AI NUTRITION LABEL BADGE                                        */
        /* ═══════════════════════════════════════════════════════════════ */
        .nutrition-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.375rem;
            font-family: 'Commit Mono', 'JetBrains Mono', monospace;
            font-size: 0.625rem;
            text-transform: uppercase;
            letter-spacing: 0.12em;
            padding: 0.25rem 0.625rem;
            border-radius: 0.25rem;
            font-weight: 500;
        }

        /* ═══════════════════════════════════════════════════════════════ */
        /* REDUCED MOTION                                                  */
        /* ═══════════════════════════════════════════════════════════════ */
        @media (prefers-reduced-motion: reduce) {
            .ticker-track { animation: none; }
            .pulse-dot { animation: none; }
            .reveal { opacity: 1; transform: none; transition: none; }
            .confidence-fill { transition: none; width: 87%; }
            .story-card { transition: none; }
            .story-card:hover { transform: none; }
            .subgrid-card { transition: none; }
            .push-notif-card { animation: none; }
            * { transition-duration: 0ms !important; animation-duration: 0ms !important; }
        }

        /* ═══════════════════════════════════════════════════════════════ */
        /* SMOOTH FONT RENDERING                                           */
        /* ═══════════════════════════════════════════════════════════════ */
        .font-editorial { text-rendering: optimizeLegibility; }

        /* ═══════════════════════════════════════════════════════════════ */
        /* INLINE CODE                                                     */
        /* ═══════════════════════════════════════════════════════════════ */
        .code-inline {
            font-family: 'Commit Mono', 'JetBrains Mono', monospace;
            font-size: 0.75rem;
            background: #e8e8e0;
            padding: 1px 5px;
            border-radius: 2px;
        }

        /* ═══════════════════════════════════════════════════════════════ */
        /* CTA INPUT                                                       */
        /* ═══════════════════════════════════════════════════════════════ */
        .cta-input {
            background: rgba(255,255,255,0.06);
            border: 1px solid rgba(255,255,255,0.15);
            color: #fafaf8;
            transition: border-color 150ms ease, background-color 150ms ease;
        }
        .cta-input::placeholder { color: #8a8a83; }
        .cta-input:focus {
            outline: none;
            border-color: #7a6b8f;
            background: rgba(255,255,255,0.1);
        }

        /* ═══════════════════════════════════════════════════════════════ */
        /* SORT BUTTONS                                                    */
        /* ═══════════════════════════════════════════════════════════════ */
        .sort-btn {
            transition: background-color 150ms ease, color 150ms ease;
        }
        .sort-btn.active {
            background-color: #1a1a18;
            color: #fafaf8;
        }

        /* ═══════════════════════════════════════════════════════════════ */
        /* NOTIFICATION BADGE PULSE                                        */
        /* ═══════════════════════════════════════════════════════════════ */
        .notif-icon-pulse {
            animation: notif-badge-pulse 2s ease-in-out infinite;
        }
    </style>
</head>

<body class="bg-paper-50 text-ink-900 font-sans">

    <!-- ═══════════════════════════════════════════════════════════════ -->
    <!-- 1. WIRE TICKER                                                    -->
    <!-- ═══════════════════════════════════════════════════════════════ -->
    <div class="bg-ink-900 text-paper-50 font-mono text-[11px] leading-none overflow-hidden" role="marquee" aria-label="Breaking news ticker">
        <div class="ticker-track flex items-center whitespace-nowrap py-2.5 gap-12">
            <span class="flex items-center gap-2"><span class="text-dispatch-ember font-semibold cat-label">Breaking</span> EU AI Act enforcement enters final legislative stage — 142 in favor, 37 against</span>
            <span class="opacity-25 text-paper-50">|</span>
            <span class="flex items-center gap-2"><span class="text-dispatch-sage font-semibold cat-label">Finance</span> Global markets rally as G7 inflation data cools for third straight month</span>
            <span class="opacity-25 text-paper-50">|</span>
            <span class="flex items-center gap-2"><span class="text-dispatch-slate font-semibold cat-label">Tech</span> Apple unveils on-device AI framework with App Store integration</span>
            <span class="opacity-25 text-paper-50">|</span>
            <span class="flex items-center gap-2"><span class="text-dispatch-clay font-semibold cat-label">Politics</span> Japan central bank signals end to negative interest rate era</span>
            <span class="opacity-25 text-paper-50">|</span>
            <span class="flex items-center gap-2"><span class="text-dispatch-violet font-semibold cat-label">Culture</span> Major K-pop agency launches AI artist management division</span>
            <span class="opacity-25 text-paper-50">|</span>
            <span class="flex items-center gap-2"><span class="text-dispatch-ember font-semibold cat-label">Breaking</span> Singapore MRT Cross Island Line Phase 2 alignment confirmed</span>
            <span class="opacity-25 text-paper-50">|</span>
            <!-- Duplicate for seamless scroll -->
            <span class="flex items-center gap-2"><span class="text-dispatch-ember font-semibold cat-label">Breaking</span> EU AI Act enforcement enters final legislative stage — 142 in favor, 37 against</span>
            <span class="opacity-25 text-paper-50">|</span>
            <span class="flex items-center gap-2"><span class="text-dispatch-sage font-semibold cat-label">Finance</span> Global markets rally as G7 inflation data cools for third straight month</span>
            <span class="opacity-25 text-paper-50">|</span>
            <span class="flex items-center gap-2"><span class="text-dispatch-slate font-semibold cat-label">Tech</span> Apple unveils on-device AI framework with App Store integration</span>
            <span class="opacity-25 text-paper-50">|</span>
            <span class="flex items-center gap-2"><span class="text-dispatch-clay font-semibold cat-label">Politics</span> Japan central bank signals end to negative interest rate era</span>
            <span class="opacity-25 text-paper-50">|</span>
            <span class="flex items-center gap-2"><span class="text-dispatch-violet font-semibold cat-label">Culture</span> Major K-pop agency launches AI artist management division</span>
            <span class="opacity-25 text-paper-50">|</span>
            <span class="flex items-center gap-2"><span class="text-dispatch-ember font-semibold cat-label">Breaking</span> Singapore MRT Cross Island Line Phase 2 alignment confirmed</span>
            <span class="opacity-25 text-paper-50">|</span>
        </div>
    </div>


    <!-- ═══════════════════════════════════════════════════════════════ -->
    <!-- 2. MASTHEAD                                                       -->
    <!-- ═══════════════════════════════════════════════════════════════ -->
    <header class="border-b border-paper-300">
        <div class="max-w-dispatch mx-auto px-4 sm:px-6 lg:px-8">
            <!-- Edition bar -->
            <div class="flex items-center justify-between py-2.5 border-b border-paper-200 font-mono text-[11px] text-ink-400">
                <div class="flex items-center gap-4">
                    <span class="cat-label">Edition 1.0</span>
                    <span class="hidden sm:inline text-paper-300">&mdash;</span>
                    <span class="hidden sm:inline">10 June 2026</span>
                </div>
                <div class="flex items-center gap-4">
                    <span class="flex items-center gap-1.5">
                        <span class="w-1.5 h-1.5 rounded-full bg-dispatch-ember pulse-dot"></span>
                        <span class="text-dispatch-ember font-medium cat-label">Live</span>
                    </span>
                    <span class="hidden sm:inline">SGT 14:30</span>
                </div>
            </div>

            <!-- Wordmark -->
            <div class="py-6 sm:py-8 text-center">
                <h1 class="font-editorial text-5xl sm:text-6xl lg:text-7xl tracking-tight text-ink-900" style="line-height:1.05">
                    OneStopNews
                </h1>
                <p class="mt-2 font-mono text-[12px] text-ink-300 cat-label-wide tracking-[.25em]">Your Briefing Room</p>
            </div>
        </div>
    </header>


    <!-- ═══════════════════════════════════════════════════════════════ -->
    <!-- 3. CATEGORY NAVIGATION (Sticky)                                   -->
    <!-- ═══════════════════════════════════════════════════════════════ -->
    <nav class="sticky top-0 z-40 bg-paper-50/95 backdrop-blur-sm border-b border-paper-300" aria-label="Topic categories">
        <div class="max-w-dispatch mx-auto px-4 sm:px-6 lg:px-8">
            <div class="category-nav flex items-center gap-1 py-2.5 overflow-x-auto" role="tablist">
                <button role="tab" aria-selected="true" class="cat-nav-btn flex items-center gap-2 px-3 py-1.5 rounded-sm text-sm font-medium whitespace-nowrap border-b-2 border-dispatch-ember text-ink-900 bg-dispatch-ember-light/50 transition-colors 150ms">
                    <span class="w-2 h-2 rounded-full bg-dispatch-ember"></span>
                    Top Stories
                    <span class="font-mono text-[10px] text-ink-400 ml-0.5">247</span>
                </button>
                <button role="tab" aria-selected="false" class="cat-nav-btn flex items-center gap-2 px-3 py-1.5 rounded-sm text-sm font-medium whitespace-nowrap border-b-2 border-transparent text-ink-600 hover:text-ink-900 hover:bg-paper-100 transition-colors 150ms">
                    <span class="w-2 h-2 rounded-full bg-dispatch-clay"></span>
                    Local
                    <span class="font-mono text-[10px] text-ink-400 ml-0.5">83</span>
                </button>
                <button role="tab" aria-selected="false" class="cat-nav-btn flex items-center gap-2 px-3 py-1.5 rounded-sm text-sm font-medium whitespace-nowrap border-b-2 border-transparent text-ink-600 hover:text-ink-900 hover:bg-paper-100 transition-colors 150ms">
                    <span class="w-2 h-2 rounded-full bg-dispatch-slate"></span>
                    Tech
                    <span class="font-mono text-[10px] text-ink-400 ml-0.5">156</span>
                </button>
                <button role="tab" aria-selected="false" class="cat-nav-btn flex items-center gap-2 px-3 py-1.5 rounded-sm text-sm font-medium whitespace-nowrap border-b-2 border-transparent text-ink-600 hover:text-ink-900 hover:bg-paper-100 transition-colors 150ms">
                    <span class="w-2 h-2 rounded-full bg-dispatch-slate"></span>
                    Global
                    <span class="font-mono text-[10px] text-ink-400 ml-0.5">194</span>
                </button>
                <button role="tab" aria-selected="false" class="cat-nav-btn flex items-center gap-2 px-3 py-1.5 rounded-sm text-sm font-medium whitespace-nowrap border-b-2 border-transparent text-ink-600 hover:text-ink-900 hover:bg-paper-100 transition-colors 150ms">
                    <span class="w-2 h-2 rounded-full bg-dispatch-sage"></span>
                    Finance
                    <span class="font-mono text-[10px] text-ink-400 ml-0.5">121</span>
                </button>
                <button role="tab" aria-selected="false" class="cat-nav-btn flex items-center gap-2 px-3 py-1.5 rounded-sm text-sm font-medium whitespace-nowrap border-b-2 border-transparent text-ink-600 hover:text-ink-900 hover:bg-paper-100 transition-colors 150ms">
                    <span class="w-2 h-2 rounded-full bg-dispatch-clay"></span>
                    Politics
                    <span class="font-mono text-[10px] text-ink-400 ml-0.5">68</span>
                </button>
                <button role="tab" aria-selected="false" class="cat-nav-btn flex items-center gap-2 px-3 py-1.5 rounded-sm text-sm font-medium whitespace-nowrap border-b-2 border-transparent text-ink-600 hover:text-ink-900 hover:bg-paper-100 transition-colors 150ms">
                    <span class="w-2 h-2 rounded-full bg-dispatch-violet"></span>
                    Culture
                    <span class="font-mono text-[10px] text-ink-400 ml-0.5">92</span>
                </button>
            </div>
        </div>
    </nav>


    <!-- ═══════════════════════════════════════════════════════════════ -->
    <!-- 4. LEAD STORY (The Hero IS the News)                              -->
    <!-- ═══════════════════════════════════════════════════════════════ -->
    <section class="max-w-dispatch mx-auto px-4 sm:px-6 lg:px-8 pt-8 pb-6 reveal" aria-label="Lead story">
        <div class="flex items-center gap-3 mb-4">
            <span class="w-2.5 h-2.5 rounded-full bg-dispatch-slate"></span>
            <span class="font-mono text-[11px] cat-label text-dispatch-slate font-semibold">Tech News / AI &amp; ML</span>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-10">
            <!-- Image -->
            <div class="lg:col-span-7">
                <div class="relative overflow-hidden bg-paper-200 aspect-[16/9] lg:aspect-[16/10]">
                    <img src="https://picsum.photos/seed/ai-regulation-2026/1200/750.jpg"
                         alt="European Parliament building during a key legislative session on AI regulation"
                         class="w-full h-full object-cover"
                         width="1200" height="750" loading="eager">
                    <div class="absolute top-3 left-3 flex items-center gap-1.5 bg-dispatch-ember/90 px-2 py-1 rounded-sm">
                        <span class="w-1.5 h-1.5 rounded-full bg-white pulse-dot"></span>
                        <span class="font-mono text-[10px] text-white font-semibold cat-label">Breaking</span>
                    </div>
                </div>
            </div>

            <!-- Headline + Meta -->
            <div class="lg:col-span-5 flex flex-col justify-center">
                <h2 class="font-editorial text-3xl sm:text-4xl lg:text-[44px] font-bold leading-[1.08] tracking-tight text-ink-900">
                    The Alignment Problem Is Now a Policy Problem
                </h2>
                <div class="mt-4 flex flex-wrap items-center gap-x-3 gap-y-1 font-mono text-[11px] text-ink-400">
                    <span class="flex items-center gap-1"><i data-lucide="users" class="w-3 h-3"></i> Reuters, AP, TechCrunch</span>
                    <span aria-hidden="true">&middot;</span>
                    <span>42 min ago</span>
                    <span aria-hidden="true">&middot;</span>
                    <span class="flex items-center gap-1 text-dispatch-sage"><i data-lucide="file-text" class="w-3 h-3"></i> 3 sources</span>
                </div>
                <p class="mt-4 text-ink-600 text-[15px] leading-relaxed">
                    As the EU's AI Act enforcement framework enters its final legislative stage, the debate has shifted from technical alignment to geopolitical competition. Three major outlets now cover the rift between member states on enforcement timelines — with the August 2026 deadline approaching.
                </p>
                <div class="mt-5 flex flex-wrap items-center gap-3">
                    <span class="inline-flex items-center gap-1.5 bg-dispatch-ember-light/60 text-dispatch-ember border border-dispatch-ember/20 px-2.5 py-1 rounded-sm font-mono text-[11px] font-medium">
                        <i data-lucide="sparkles" class="w-3 h-3"></i> AI Summary Available
                    </span>
                    <a href="#ai-summary-demo" class="inline-flex items-center gap-1.5 text-ink-900 font-medium text-sm hover:underline underline-offset-2 transition-colors 150ms">
                        See AI Summary <i data-lucide="arrow-down" class="w-3.5 h-3.5"></i>
                    </a>
                </div>
            </div>
        </div>
    </section>

    <hr class="dispatch-rule max-w-dispatch mx-auto">


    <!-- ═══════════════════════════════════════════════════════════════ -->
    <!-- 5. TRENDING BAR (NEW — Reader-Powered)                            -->
    <!-- ═══════════════════════════════════════════════════════════════ -->
    <section class="max-w-dispatch mx-auto px-4 sm:px-6 lg:px-8 py-6 reveal" aria-label="Trending among readers">
        <div class="flex items-center gap-3 mb-4">
            <span class="font-mono text-[11px] cat-label-wide text-ink-400 tracking-[.15em]">Trending Among Readers</span>
            <span class="flex items-center gap-1 font-mono text-[10px] text-dispatch-ember">
                <span class="w-1.5 h-1.5 rounded-full bg-dispatch-ember pulse-dot"></span> Live
            </span>
        </div>
        <div class="trending-scroll flex gap-3 overflow-x-auto pb-2">
            <article class="flex-shrink-0 w-64 border border-paper-200 rounded-sm p-3 bg-white hover:bg-paper-100 transition-colors 150ms cursor-pointer">
                <div class="flex items-center gap-2 mb-2">
                    <span class="w-1.5 h-1.5 rounded-full bg-dispatch-ember shrink-0"></span>
                    <span class="font-mono text-[10px] cat-label text-dispatch-ember font-semibold">Breaking</span>
                </div>
                <h4 class="font-editorial text-sm font-bold leading-snug text-ink-900 line-clamp-2">SpaceX Starship completes first orbital refueling test</h4>
                <div class="mt-2 flex items-center gap-2 font-mono text-[10px] text-ink-400">
                    <span class="flex items-center gap-1"><i data-lucide="eye" class="w-3 h-3"></i> 12.4k</span>
                    <span>18 min ago</span>
                </div>
            </article>
            <article class="flex-shrink-0 w-64 border border-paper-200 rounded-sm p-3 bg-white hover:bg-paper-100 transition-colors 150ms cursor-pointer">
                <div class="flex items-center gap-2 mb-2">
                    <span class="w-1.5 h-1.5 rounded-full bg-dispatch-sage shrink-0"></span>
                    <span class="font-mono text-[10px] cat-label text-dispatch-sage font-semibold">Finance</span>
                </div>
                <h4 class="font-editorial text-sm font-bold leading-snug text-ink-900 line-clamp-2">Markets surge as G7 inflation cools for third consecutive month</h4>
                <div class="mt-2 flex items-center gap-2 font-mono text-[10px] text-ink-400">
                    <span class="flex items-center gap-1"><i data-lucide="eye" class="w-3 h-3"></i> 9.8k</span>
                    <span>1h ago</span>
                </div>
            </article>
            <article class="flex-shrink-0 w-64 border border-paper-200 rounded-sm p-3 bg-white hover:bg-paper-100 transition-colors 150ms cursor-pointer">
                <div class="flex items-center gap-2 mb-2">
                    <span class="w-1.5 h-1.5 rounded-full bg-dispatch-slate shrink-0"></span>
                    <span class="font-mono text-[10px] cat-label text-dispatch-slate font-semibold">Tech</span>
                </div>
                <h4 class="font-editorial text-sm font-bold leading-snug text-ink-900 line-clamp-2">Apple on-device AI framework opens to third-party developers</h4>
                <div class="mt-2 flex items-center gap-2 font-mono text-[10px] text-ink-400">
                    <span class="flex items-center gap-1"><i data-lucide="eye" class="w-3 h-3"></i> 7.2k</span>
                    <span>2h ago</span>
                </div>
            </article>
            <article class="flex-shrink-0 w-64 border border-paper-200 rounded-sm p-3 bg-white hover:bg-paper-100 transition-colors 150ms cursor-pointer">
                <div class="flex items-center gap-2 mb-2">
                    <span class="w-1.5 h-1.5 rounded-full bg-dispatch-clay shrink-0"></span>
                    <span class="font-mono text-[10px] cat-label text-dispatch-clay font-semibold">Politics</span>
                </div>
                <h4 class="font-editorial text-sm font-bold leading-snug text-ink-900 line-clamp-2">GE2025 enters final week with housing policy debate intensifying</h4>
                <div class="mt-2 flex items-center gap-2 font-mono text-[10px] text-ink-400">
                    <span class="flex items-center gap-1"><i data-lucide="eye" class="w-3 h-3"></i> 6.5k</span>
                    <span>3h ago</span>
                </div>
            </article>
            <article class="flex-shrink-0 w-64 border border-paper-200 rounded-sm p-3 bg-white hover:bg-paper-100 transition-colors 150ms cursor-pointer">
                <div class="flex items-center gap-2 mb-2">
                    <span class="w-1.5 h-1.5 rounded-full bg-dispatch-violet shrink-0"></span>
                    <span class="font-mono text-[10px] cat-label text-dispatch-violet font-semibold">Culture</span>
                </div>
                <h4 class="font-editorial text-sm font-bold leading-snug text-ink-900 line-clamp-2">K-pop AI artist management division sparks industry debate</h4>
                <div class="mt-2 flex items-center gap-2 font-mono text-[10px] text-ink-400">
                    <span class="flex items-center gap-1"><i data-lucide="eye" class="w-3 h-3"></i> 5.1k</span>
                    <span>4h ago</span>
                </div>
            </article>
        </div>
    </section>

    <hr class="dispatch-rule max-w-dispatch mx-auto">


    <!-- ═══════════════════════════════════════════════════════════════ -->
    <!-- 6. STORY GRID (CSS Subgrid — Perfect Alignment)                   -->
    <!-- ═══════════════════════════════════════════════════════════════ -->
    <section class="max-w-dispatch mx-auto px-4 sm:px-6 lg:px-8 py-8" aria-label="Latest stories">
        <div class="flex items-center justify-between mb-6">
            <h3 class="font-mono text-[12px] cat-label text-ink-400 tracking-[.15em]">Latest Stories</h3>
            <div class="flex items-center gap-2 font-mono text-[11px] text-ink-400">
                <button class="sort-btn active px-2 py-1 rounded-sm" aria-pressed="true">Latest</button>
                <button class="sort-btn px-2 py-1 rounded-sm" aria-pressed="false">Impact</button>
                <button class="sort-btn px-2 py-1 rounded-sm" aria-pressed="false">Summarized</button>
            </div>
        </div>

        <!-- CSS Subgrid — headlines, excerpts, and metadata align perfectly across every row -->
        <div class="subgrid-parent">
            <!-- Card 1 -->
            <article class="subgrid-card reveal" role="article">
                <div class="flex items-center gap-2 mb-0.5">
                    <span class="w-1.5 h-1.5 rounded-full bg-dispatch-sage shrink-0"></span>
                    <span class="font-mono text-[10px] cat-label text-dispatch-sage font-semibold">Finance / Markets</span>
                </div>
                <h4 class="font-editorial text-xl font-bold leading-tight text-ink-900 group-hover:text-dispatch-ember transition-colors 150ms">
                    Global Markets Rally as G7 Inflation Cools for Third Straight Month
                </h4>
                <p class="font-sans text-sm leading-relaxed text-ink-600 line-clamp-3">
                    Benchmark indices across major economies posted gains after synchronized inflation data suggested central banks may have room to ease monetary policy in Q3. Analysts caution that the trend remains fragile.
                </p>
                <div class="flex items-center gap-3 font-mono text-[10px] uppercase tracking-wider text-ink-400 mt-auto">
                    <span class="text-dispatch-slate font-medium truncate">Bloomberg, Reuters</span>
                    <span class="w-1 h-1 rounded-full bg-ink-400/50 shrink-0" aria-hidden="true"></span>
                    <time class="shrink-0">1h ago</time>
                    <span class="w-1 h-1 rounded-full bg-ink-400/50 shrink-0" aria-hidden="true"></span>
                    <span class="text-dispatch-ember font-medium shrink-0">AI Brief</span>
                </div>
            </article>

            <!-- Card 2 -->
            <article class="subgrid-card reveal reveal-delay-1" role="article">
                <div class="flex items-center gap-2 mb-0.5">
                    <span class="w-1.5 h-1.5 rounded-full bg-dispatch-slate shrink-0"></span>
                    <span class="font-mono text-[10px] cat-label text-dispatch-slate font-semibold">Tech / Apple &amp; Devices</span>
                </div>
                <h4 class="font-editorial text-xl font-bold leading-tight text-ink-900 group-hover:text-dispatch-ember transition-colors 150ms">
                    Apple Unveils On-Device AI Framework With App Store Integration
                </h4>
                <p class="font-sans text-sm leading-relaxed text-ink-600 line-clamp-3">
                    The new framework allows third-party apps to tap into Apple Intelligence models running locally on iPhone and Mac. Developers can now ship AI features that never leave the device.
                </p>
                <div class="flex items-center gap-3 font-mono text-[10px] uppercase tracking-wider text-ink-400 mt-auto">
                    <span class="text-dispatch-slate font-medium truncate">The Verge, 9to5Mac</span>
                    <span class="w-1 h-1 rounded-full bg-ink-400/50 shrink-0" aria-hidden="true"></span>
                    <time class="shrink-0">2h ago</time>
                </div>
            </article>

            <!-- Card 3 -->
            <article class="subgrid-card reveal reveal-delay-2" role="article">
                <div class="flex items-center gap-2 mb-0.5">
                    <span class="w-1.5 h-1.5 rounded-full bg-dispatch-clay shrink-0"></span>
                    <span class="font-mono text-[10px] cat-label text-dispatch-clay font-semibold">Politics / SG Politics</span>
                </div>
                <h4 class="font-editorial text-xl font-bold leading-tight text-ink-900 group-hover:text-dispatch-ember transition-colors 150ms">
                    GE2025: Campaign Enters Final Week With Housing Policy Focus
                </h4>
                <p class="font-sans text-sm leading-relaxed text-ink-600 line-clamp-3">
                    All major parties have now released their housing manifestos as the general election campaign enters its decisive final week. BTO pricing and resale market reform dominate the discourse.
                </p>
                <div class="flex items-center gap-3 font-mono text-[10px] uppercase tracking-wider text-ink-400 mt-auto">
                    <span class="text-dispatch-slate font-medium truncate">CNA, The Straits Times</span>
                    <span class="w-1 h-1 rounded-full bg-ink-400/50 shrink-0" aria-hidden="true"></span>
                    <time class="shrink-0">3h ago</time>
                </div>
            </article>

            <!-- Card 4 -->
            <article class="subgrid-card reveal reveal-delay-3" role="article">
                <div class="flex items-center gap-2 mb-0.5">
                    <span class="w-1.5 h-1.5 rounded-full bg-dispatch-violet shrink-0"></span>
                    <span class="font-mono text-[10px] cat-label text-dispatch-violet font-semibold">Culture / K-Culture</span>
                </div>
                <h4 class="font-editorial text-xl font-bold leading-tight text-ink-900 group-hover:text-dispatch-ember transition-colors 150ms">
                    Major K-Pop Agency Launches AI Artist Management Division
                </h4>
                <p class="font-sans text-sm leading-relaxed text-ink-600 line-clamp-3">
                    The new division will use AI for tour logistics, fan engagement analytics, and virtual artist development. Industry observers are divided on the implications for human artists.
                </p>
                <div class="flex items-center gap-3 font-mono text-[10px] uppercase tracking-wider text-ink-400 mt-auto">
                    <span class="text-dispatch-slate font-medium truncate">Korea Herald</span>
                    <span class="w-1 h-1 rounded-full bg-ink-400/50 shrink-0" aria-hidden="true"></span>
                    <time class="shrink-0">4h ago</time>
                    <span class="w-1 h-1 rounded-full bg-ink-400/50 shrink-0" aria-hidden="true"></span>
                    <span class="text-dispatch-ember font-medium shrink-0">AI Brief</span>
                </div>
            </article>

            <!-- Card 5 -->
            <article class="subgrid-card reveal reveal-delay-4" role="article">
                <div class="flex items-center gap-2 mb-0.5">
                    <span class="w-1.5 h-1.5 rounded-full bg-dispatch-slate shrink-0"></span>
                    <span class="font-mono text-[10px] cat-label text-dispatch-slate font-semibold">Global / China</span>
                </div>
                <h4 class="font-editorial text-xl font-bold leading-tight text-ink-900 group-hover:text-dispatch-ember transition-colors 150ms">
                    China Announces $40 Billion Semiconductor Subsidy Package
                </h4>
                <p class="font-sans text-sm leading-relaxed text-ink-600 line-clamp-3">
                    The package targets domestic chip fabrication and advanced packaging R&D, intensifying the global semiconductor competition. Industry analysts expect a response from the US and EU within weeks.
                </p>
                <div class="flex items-center gap-3 font-mono text-[10px] uppercase tracking-wider text-ink-400 mt-auto">
                    <span class="text-dispatch-slate font-medium truncate">SCMP, Reuters</span>
                    <span class="w-1 h-1 rounded-full bg-ink-400/50 shrink-0" aria-hidden="true"></span>
                    <time class="shrink-0">5h ago</time>
                </div>
            </article>

            <!-- Card 6 -->
            <article class="subgrid-card reveal reveal-delay-5" role="article">
                <div class="flex items-center gap-2 mb-0.5">
                    <span class="w-1.5 h-1.5 rounded-full bg-dispatch-sage shrink-0"></span>
                    <span class="font-mono text-[10px] cat-label text-dispatch-sage font-semibold">Finance / Crypto</span>
                </div>
                <h4 class="font-editorial text-xl font-bold leading-tight text-ink-900 group-hover:text-dispatch-ember transition-colors 150ms">
                    Bitcoin Breaches $100K as Institutional Adoption Accelerates
                </h4>
                <p class="font-sans text-sm leading-relaxed text-ink-600 line-clamp-3">
                    The cryptocurrency crossed the six-figure threshold for the first time, driven by spot ETF inflows and new institutional custody products. Trading volumes hit all-time highs.
                </p>
                <div class="flex items-center gap-3 font-mono text-[10px] uppercase tracking-wider text-ink-400 mt-auto">
                    <span class="text-dispatch-slate font-medium truncate">CoinDesk, Bloomberg</span>
                    <span class="w-1 h-1 rounded-full bg-ink-400/50 shrink-0" aria-hidden="true"></span>
                    <time class="shrink-0">6h ago</time>
                    <span class="w-1 h-1 rounded-full bg-ink-400/50 shrink-0" aria-hidden="true"></span>
                    <span class="text-dispatch-ember font-medium shrink-0">AI Brief</span>
                </div>
            </article>
        </div>
    </section>


    <!-- ═══ THICK SECTION BREAK ═══ -->
    <hr class="dispatch-rule-thick max-w-dispatch mx-auto my-4">


    <!-- ═══════════════════════════════════════════════════════════════ -->
    <!-- 7. CONCEPT INTRODUCTION                                           -->
    <!-- ═══════════════════════════════════════════════════════════════ -->
    <section class="max-w-dispatch mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24 reveal">
        <div class="max-w-3xl">
            <span class="font-mono text-[11px] cat-label-wide text-ink-400 tracking-[.2em]">Why OneStopNews</span>
            <h2 class="mt-4 font-editorial text-3xl sm:text-4xl lg:text-5xl font-bold leading-[1.08] tracking-tight text-ink-900" style="text-wrap: balance">
                News organized by<br>
                <em class="not-italic text-dispatch-slate">what it's about</em>,<br>
                not who published it.
            </h2>
            <p class="mt-6 text-ink-600 text-base sm:text-lg leading-relaxed max-w-xl">
                You shouldn't need to visit seven sites to understand one story. OneStopNews ingests hundreds of sources, clusters coverage by topic, and surfaces what matters — with AI summaries that cite every source they drew from.
            </p>
            <div class="mt-8 flex flex-wrap gap-4">
                <a href="#ai-summary-demo" class="inline-flex items-center gap-2 bg-ink-900 text-paper-50 px-5 py-2.5 rounded-sm font-medium text-sm hover:bg-ink-700 transition-colors 150ms">
                    See the AI Nutrition Label <i data-lucide="arrow-down" class="w-4 h-4"></i>
                </a>
                <a href="#early-access" class="inline-flex items-center gap-2 border border-ink-900 text-ink-900 px-5 py-2.5 rounded-sm font-medium text-sm hover:bg-ink-900 hover:text-paper-50 transition-colors 150ms">
                    Request Early Access
                </a>
            </div>
        </div>
    </section>


    <!-- ═══════════════════════════════════════════════════════════════ -->
    <!-- 8. AI SUMMARY DEMO — THE NUTRITION LABEL (Major Rewrite)         -->
    <!-- ═══════════════════════════════════════════════════════════════ -->
    <section id="ai-summary-demo" class="bg-paper-100 border-y border-paper-300 py-16 lg:py-24" aria-label="AI Summary feature demonstration — AI Nutrition Label">
        <div class="max-w-dispatch mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16">
                <!-- Left: Explanation -->
                <div class="lg:col-span-4 reveal">
                    <span class="font-mono text-[11px] cat-label-wide text-dispatch-sage tracking-[.2em]">Core Feature</span>
                    <h2 class="mt-4 font-editorial text-2xl sm:text-3xl font-bold leading-tight text-ink-900">
                        The AI Nutrition Label
                    </h2>
                    <p class="mt-4 text-ink-600 text-sm leading-relaxed">
                        Every AI summary comes with a full transparency label — model name, coverage percentage, what the AI did, and every source cited inline. EU AI Act Article 50 compliant. Not a black box.
                    </p>
                    <div class="mt-6 space-y-3 text-sm text-ink-600">
                        <div class="feature-check">Every claim traced to a source</div>
                        <div class="feature-check">"What the AI did" in plain language</div>
                        <div class="feature-check">Confidence &amp; coverage visible</div>
                        <div class="feature-check">"Read original" always one click away</div>
                        <div class="feature-check">Model, tokens &amp; generation time disclosed</div>
                        <div class="feature-check">Machine-readable C2PA provenance</div>
                    </div>
                </div>

                <!-- Right: Interactive Demo Panel -->
                <div class="lg:col-span-8 reveal reveal-delay-2">
                    <div class="bg-white border border-paper-300 rounded-sm shadow-panel overflow-hidden">
                        <!-- Panel Header -->
                        <div class="flex items-center justify-between border-b border-paper-200 px-5 py-3">
                            <div class="flex items-center gap-4">
                                <button id="tab-summary" class="tab-btn active text-sm font-semibold text-ink-900" onclick="switchTab('summary')">AI Summary</button>
                                <button id="tab-excerpt" class="tab-btn text-sm font-semibold text-ink-400" onclick="switchTab('excerpt')">Original Excerpt</button>
                            </div>
                            <span class="nutrition-badge bg-dispatch-ember-light/60 text-dispatch-ember border border-dispatch-ember/20">
                                <i data-lucide="sparkles" class="w-3 h-3"></i> AI-Generated
                            </span>
                        </div>

                        <!-- Summary Content -->
                        <div id="panel-summary" class="p-5 sm:p-6">
                            <!-- AI Nutrition Label Header -->
                            <div class="flex items-center gap-2 mb-4 font-mono text-[10px] uppercase tracking-widest text-ink-600">
                                <span class="w-1.5 h-1.5 rounded-full bg-dispatch-ember" aria-hidden="true"></span>
                                AI Briefing &middot; Claude 4.5 Haiku &middot; 42 min ago
                            </div>

                            <p class="text-ink-700 text-[15px] leading-relaxed">
                                The EU's AI Act enforcement framework has passed its final parliamentary vote with 142 in favor and 37 against.<sup class="citation-ref text-dispatch-violet text-xs font-mono ml-0.5">1</sup> The legislation classifies AI systems into four risk tiers, with "high-risk" systems — including those used in hiring, law enforcement, and critical infrastructure — facing mandatory conformity assessments before deployment.<sup class="citation-ref text-dispatch-violet text-xs font-mono ml-0.5">2</sup> Real-time biometric surveillance in public spaces is banned, with limited exceptions for serious criminal investigations.<sup class="citation-ref text-dispatch-violet text-xs font-mono ml-0.5">3</sup>
                            </p>

                            <div class="mt-5">
                                <span class="font-mono text-[10px] cat-label text-ink-400 font-semibold">Key Points</span>
                                <ul class="mt-2 space-y-2 text-sm text-ink-700">
                                    <li class="flex gap-2"><span class="text-dispatch-slate mt-0.5">&mdash;</span> High-risk AI systems require third-party conformity assessments before market entry</li>
                                    <li class="flex gap-2"><span class="text-dispatch-slate mt-0.5">&mdash;</span> Real-time biometric surveillance banned in public spaces with narrow law-enforcement exceptions</li>
                                    <li class="flex gap-2"><span class="text-dispatch-slate mt-0.5">&mdash;</span> Member states have 24 months to implement national enforcement bodies</li>
                                </ul>
                            </div>

                            <!-- ── AI Nutrition Label (Full Disclosure) ── -->
                            <div class="mt-6 border-t border-paper-200 pt-5 space-y-3">
                                <div class="flex items-center gap-2">
                                    <span class="w-1.5 h-1.5 rounded-full bg-dispatch-ember" aria-hidden="true"></span>
                                    <h4 class="font-mono text-[10px] uppercase tracking-widest text-ink-600 font-semibold">AI Transparency Label</h4>
                                    <span class="nutrition-badge bg-dispatch-violet/10 text-dispatch-violet border border-dispatch-violet/20 ml-2">EU AI Act Art. 50</span>
                                </div>
                                <ul class="space-y-1.5 font-sans text-xs text-ink-600">
                                    <li><span class="font-medium text-ink-900">What the AI did:</span> This is a 3-point summary of a 1,100-word article, generated from the article text as its only source.</li>
                                    <li><span class="font-medium text-ink-900">Model:</span> Claude 4.5 Haiku (Temperature: 0.1, Factual-only mode)</li>
                                    <li><span class="font-medium text-ink-900">Source Coverage:</span> 87% of article text analyzed</li>
                                    <li><span class="font-medium text-ink-900">Tokens:</span> 847 tokens used</li>
                                    <li><span class="font-medium text-ink-900">Generated:</span> 10 Jun 2026, 14:22 SGT</li>
                                    <li><span class="font-medium text-ink-900">Reviewed by editor:</span> Not yet</li>
                                    <li><span class="font-medium text-ink-900">Compliance:</span> EU AI Act Article 50 compliant — machine-readable C2PA metadata embedded</li>
                                </ul>
                            </div>

                            <!-- Citations -->
                            <div class="mt-5 pt-4 border-t border-paper-200">
                                <span class="font-mono text-[10px] cat-label text-ink-400 font-semibold">Sources Cited</span>
                                <div class="mt-2 space-y-1.5">
                                    <div class="flex items-start gap-2 text-xs">
                                        <span class="font-mono text-dispatch-violet font-semibold mt-0.5 shrink-0">[1]</span>
                                        <a href="#" class="text-ink-600 hover:text-ink-900 hover:underline underline-offset-2 transition-colors">Reuters — "EU Parliament votes on AI Act enforcement framework"</a>
                                    </div>
                                    <div class="flex items-start gap-2 text-xs">
                                        <span class="font-mono text-dispatch-violet font-semibold mt-0.5 shrink-0">[2]</span>
                                        <a href="#" class="text-ink-600 hover:text-ink-900 hover:underline underline-offset-2 transition-colors">AP News — "High-risk classification under the new AI legislation"</a>
                                    </div>
                                    <div class="flex items-start gap-2 text-xs">
                                        <span class="font-mono text-dispatch-violet font-semibold mt-0.5 shrink-0">[3]</span>
                                        <a href="#" class="text-ink-600 hover:text-ink-900 hover:underline underline-offset-2 transition-colors">TechCrunch — "Biometric surveillance ban: exceptions and scope"</a>
                                    </div>
                                </div>
                            </div>

                            <!-- Confidence Bar -->
                            <div class="mt-5 flex items-center gap-4" id="confidence-section">
                                <div class="flex-1">
                                    <div class="flex items-center justify-between mb-1">
                                        <span class="font-mono text-[10px] text-ink-400">Coverage Confidence</span>
                                        <span class="font-mono text-[10px] text-dispatch-sage font-medium">87%</span>
                                    </div>
                                    <div class="confidence-bar">
                                        <div class="confidence-fill" id="confidence-fill"></div>
                                    </div>
                                </div>
                            </div>

                            <!-- Verify with Original (Escape Hatch) -->
                            <div class="mt-5 flex items-center justify-between border-t border-paper-200 pt-4">
                                <a href="#" class="inline-flex items-center gap-1.5 font-mono text-[11px] uppercase tracking-wider text-ink-900 hover:text-dispatch-ember transition-colors 150ms font-medium">
                                    Verify with Original Source <i data-lucide="arrow-up-right" class="w-3.5 h-3.5"></i>
                                </a>
                                <button class="font-mono text-[10px] text-ink-400 hover:text-dispatch-ember transition-colors 150ms" title="Report an inaccuracy in this summary">
                                    <i data-lucide="flag" class="w-3.5 h-3.5"></i> Report
                                </button>
                            </div>
                        </div>

                        <!-- Excerpt Content (Hidden by default) -->
                        <div id="panel-excerpt" class="p-5 sm:p-6 hidden">
                            <div class="flex items-center gap-2 mb-3">
                                <span class="w-2 h-2 rounded-full bg-dispatch-slate"></span>
                                <span class="font-mono text-[10px] cat-label text-dispatch-slate font-semibold">Tech News / AI &amp; ML</span>
                            </div>
                            <p class="text-ink-700 text-[15px] leading-relaxed italic">
                                "The European Parliament has given its final approval to the AI Act enforcement framework, passing with 142 votes in favor and 37 against. The regulation, first proposed in 2021, establishes a risk-based classification system for artificial intelligence applications. High-risk systems — including those used in recruitment, law enforcement, and critical infrastructure — will be subject to mandatory conformity assessments before they can be deployed in the EU market. The legislation also includes a ban on real-time biometric identification systems in publicly accessible spaces, with narrow exceptions for serious criminal investigations. Member states now have 24 months to designate national competent authorities to enforce the rules."
                            </p>
                            <div class="mt-4 flex items-center gap-3 font-mono text-[10px] text-ink-400">
                                <span>Source: Reuters</span><span aria-hidden="true">&middot;</span><span>Published 1h ago</span>
                            </div>
                            <a href="#" class="mt-4 inline-flex items-center gap-1.5 text-ink-900 font-medium text-sm hover:underline underline-offset-2">
                                Read Full Article <i data-lucide="arrow-up-right" class="w-3.5 h-3.5"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- ═══════════════════════════════════════════════════════════════ -->
    <!-- 9. PUSH NOTIFICATION SHOWCASE (NEW)                               -->
    <!-- ═══════════════════════════════════════════════════════════════ -->
    <section class="max-w-dispatch mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24" aria-label="AI-summarised push notifications">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 items-center">
            <!-- Left: Explanation -->
            <div class="lg:col-span-5 reveal">
                <span class="font-mono text-[11px] cat-label-wide text-dispatch-ember tracking-[.2em]">Stay Informed</span>
                <h2 class="mt-4 font-editorial text-2xl sm:text-3xl font-bold leading-tight text-ink-900">
                    AI-summarised push notifications. The story, before you open the app.
                </h2>
                <p class="mt-4 text-ink-600 text-sm leading-relaxed">
                    Breaking news alerts that include a 1-sentence AI summary right in the notification. Understand what happened without unlocking your phone. Cross-platform — iOS Safari 16.4+, Android, and desktop browsers.
                </p>
                <div class="mt-6 space-y-3 text-sm text-ink-600">
                    <div class="feature-check">1-sentence AI summary in every alert</div>
                    <div class="feature-check">Per-category opt-in — you control what you get</div>
                    <div class="feature-check">Quiet hours &amp; daily limits</div>
                    <div class="feature-check">40%+ opt-in rate on comparable products</div>
                </div>
            </div>

            <!-- Right: Phone Mockup -->
            <div class="lg:col-span-7 reveal reveal-delay-2 flex justify-center">
                <div class="push-demo-phone w-full max-w-[320px]">
                    <div class="push-demo-screen p-4">
                        <!-- Mock status bar -->
                        <div class="flex items-center justify-between mb-4 font-sans text-[10px] text-ink-400">
                            <span>10:42</span>
                            <span class="flex items-center gap-1"><span class="w-1 h-1 rounded-full bg-ink-400"></span> 5G</span>
                        </div>
                        <!-- Notification card -->
                        <div class="push-notif-card p-4 mb-3">
                            <div class="flex items-center gap-2 mb-2">
                                <div class="w-5 h-5 rounded-sm bg-dispatch-ember flex items-center justify-center notif-icon-pulse">
                                    <span class="text-white font-editorial text-[10px] font-bold">ON</span>
                                </div>
                                <span class="font-sans text-xs font-semibold text-ink-900">OneStopNews</span>
                                <span class="font-mono text-[9px] text-ink-400 ml-auto">just now</span>
                            </div>
                            <p class="font-sans text-sm font-medium text-ink-900 leading-snug mb-1">
                                EU AI Act passes final vote — 142 in favor, 37 against
                            </p>
                            <p class="font-sans text-xs text-ink-600 leading-relaxed">
                                <span class="text-dispatch-ember font-medium">AI Summary:</span> Parliament approved the enforcement framework with high-risk AI facing mandatory assessments and biometric surveillance banned in public spaces. 24-month implementation window.
                            </p>
                        </div>
                        <!-- Second notification -->
                        <div class="push-notif-card p-4 mb-3 opacity-80">
                            <div class="flex items-center gap-2 mb-2">
                                <div class="w-5 h-5 rounded-sm bg-dispatch-sage flex items-center justify-center">
                                    <span class="text-white font-editorial text-[10px] font-bold">ON</span>
                                </div>
                                <span class="font-sans text-xs font-semibold text-ink-900">OneStopNews</span>
                                <span class="font-mono text-[9px] text-ink-400 ml-auto">8m ago</span>
                            </div>
                            <p class="font-sans text-sm font-medium text-ink-900 leading-snug mb-1">
                                Markets surge as G7 inflation data cools
                            </p>
                            <p class="font-sans text-xs text-ink-600 leading-relaxed">
                                <span class="text-dispatch-sage font-medium">AI Summary:</span> Benchmark indices across major economies posted gains after synchronized inflation data suggested central banks may ease monetary policy in Q3.
                            </p>
                        </div>
                        <!-- Home indicator -->
                        <div class="flex justify-center mt-2">
                            <div class="w-24 h-1 rounded-full bg-ink-200"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- ═══════════════════════════════════════════════════════════════ -->
    <!-- 10. HOW IT WORKS                                                  -->
    <!-- ═══════════════════════════════════════════════════════════════ -->
    <section class="bg-paper-100 border-y border-paper-300 py-16 lg:py-24" aria-label="How it works">
        <div class="max-w-dispatch mx-auto px-4 sm:px-6 lg:px-8">
            <span class="font-mono text-[11px] cat-label-wide text-ink-400 tracking-[.2em] reveal">How It Works</span>
            <div class="mt-8 grid grid-cols-1 md:grid-cols-3 gap-8 lg:gap-12">
                <!-- Step 1 -->
                <div class="reveal reveal-delay-1">
                    <div class="flex items-center gap-3 mb-4">
                        <span class="font-mono text-[11px] text-ink-300 font-semibold">01</span>
                        <div class="h-px flex-1 bg-paper-300"></div>
                    </div>
                    <h3 class="font-editorial text-2xl font-bold text-ink-900">Ingest</h3>
                    <p class="mt-3 text-ink-600 text-sm leading-relaxed">
                        200+ sources polled continuously via RSS, Atom, and API adapters. Every article normalized, deduplicated by canonical URL and content hash, and routed to its topic cluster.
                    </p>
                    <div class="mt-4 font-mono text-[10px] text-ink-400 space-y-1">
                        <div>BullMQ scheduler &middot; 5&ndash;30 min intervals</div>
                        <div>Source health monitoring &middot; Auto-retry</div>
                        <div>Zod-validated ingestion pipeline</div>
                    </div>
                </div>

                <!-- Step 2 -->
                <div class="reveal reveal-delay-2">
                    <div class="flex items-center gap-3 mb-4">
                        <span class="font-mono text-[11px] text-ink-300 font-semibold">02</span>
                        <div class="h-px flex-1 bg-paper-300"></div>
                    </div>
                    <h3 class="font-editorial text-2xl font-bold text-ink-900">Organize</h3>
                    <p class="mt-3 text-ink-600 text-sm leading-relaxed">
                        Stories clustered by topic, not outlet. Importance scores computed from recency, source priority, cluster size, and category relevance — so the biggest stories surface first.
                    </p>
                    <div class="mt-4 font-mono text-[10px] text-ink-400 space-y-1">
                        <div>7 categories &middot; 30+ subcategories</div>
                        <div>BM25-ranked full-text search</div>
                        <div>Composite importance scoring</div>
                    </div>
                </div>

                <!-- Step 3 -->
                <div class="reveal reveal-delay-3">
                    <div class="flex items-center gap-3 mb-4">
                        <span class="font-mono text-[11px] text-ink-300 font-semibold">03</span>
                        <div class="h-px flex-1 bg-paper-300"></div>
                    </div>
                    <h3 class="font-editorial text-2xl font-bold text-ink-900">Distill</h3>
                    <p class="mt-3 text-ink-600 text-sm leading-relaxed">
                        On-demand AI summaries with every source cited inline. Every summary carries an AI Nutrition Label with model info, coverage percentage, and an EU AI Act compliance statement. Fidelity over brevity — always.
                    </p>
                    <div class="mt-4 font-mono text-[10px] text-ink-400 space-y-1">
                        <div>Claude 4.5 Haiku &middot; Source-cited by default</div>
                        <div>87% average content coverage</div>
                        <div>&lt;1% factual error rate (audited)</div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- ═══════════════════════════════════════════════════════════════ -->
    <!-- 11. SEARCH & PERFORMANCE                                          -->
    <!-- ═══════════════════════════════════════════════════════════════ -->
    <section class="max-w-dispatch mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-20">
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <!-- Search -->
            <div class="reveal">
                <span class="font-mono text-[11px] cat-label-wide text-ink-400 tracking-[.2em]">Search</span>
                <h2 class="mt-3 font-editorial text-2xl font-bold text-ink-900">BM25-ranked keyword search. No Elasticsearch.</h2>
                <p class="mt-3 text-ink-600 text-sm leading-relaxed">
                    PostgreSQL GIN-indexed full-text search with <code class="code-inline">tsvector</code> generated columns and <code class="code-inline">pg_textsearch</code> BM25 for relevance ranking. Title-weighted (A) and body-weighted (B) fields. Zero external search infrastructure — everything in one database.
                </p>
                <div class="mt-5 font-mono text-[10px] text-ink-400 space-y-1.5">
                    <div class="flex items-center gap-2"><span class="w-1.5 h-1.5 rounded-full bg-dispatch-slate"></span> Debounced 300ms client-side</div>
                    <div class="flex items-center gap-2"><span class="w-1.5 h-1.5 rounded-full bg-dispatch-slate"></span> GIN-indexed for sub-300ms p95</div>
                    <div class="flex items-center gap-2"><span class="w-1.5 h-1.5 rounded-full bg-dispatch-slate"></span> pg_trgm for fuzzy / zero-result fallback</div>
                </div>
            </div>

            <!-- Speed Metrics -->
            <div class="reveal reveal-delay-2">
                <span class="font-mono text-[11px] cat-label-wide text-ink-400 tracking-[.2em]">Performance</span>
                <h2 class="mt-3 font-editorial text-2xl font-bold text-ink-900">Built for the speed of news.</h2>
                <p class="mt-3 text-ink-600 text-sm leading-relaxed">
                    Next.js 16.2 with Partial Pre-Rendering delivers a static shell in under 800ms, with dynamic content streamed via React Suspense. Redis feed slices keep hot categories instant. React 19.2 native View Transitions for smooth topic switching.
                </p>
                <div class="mt-6 grid grid-cols-3 gap-4">
                    <div class="border border-paper-200 rounded-sm p-3 bg-white">
                        <div class="font-mono text-[10px] text-ink-400 cat-label">Feed API p95</div>
                        <div class="mt-1 font-editorial text-2xl font-bold text-ink-900 metric-value">&le;500<span class="text-sm font-sans text-ink-400">ms</span></div>
                    </div>
                    <div class="border border-paper-200 rounded-sm p-3 bg-white">
                        <div class="font-mono text-[10px] text-ink-400 cat-label">LCP (feed)</div>
                        <div class="mt-1 font-editorial text-2xl font-bold text-ink-900 metric-value">&le;1.5<span class="text-sm font-sans text-ink-400">s</span></div>
                    </div>
                    <div class="border border-paper-200 rounded-sm p-3 bg-white">
                        <div class="font-mono text-[10px] text-ink-400 cat-label">Uptime</div>
                        <div class="mt-1 font-editorial text-2xl font-bold text-ink-900 metric-value">99.5<span class="text-sm font-sans text-ink-400">%</span></div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- ═══════════════════════════════════════════════════════════════ -->
    <!-- 12. TRUST (Full-Bleed Ink Section)                                -->
    <!-- ═══════════════════════════════════════════════════════════════ -->
    <section class="bg-ink-900 py-16 lg:py-24" aria-label="AI governance and trust commitments">
        <div class="max-w-dispatch mx-auto px-4 sm:px-6 lg:px-8">
            <div class="reveal">
                <span class="font-mono text-[11px] cat-label-wide text-ink-300 tracking-[.2em]">AI Governance</span>
                <h2 class="mt-4 font-editorial text-3xl sm:text-4xl font-bold leading-[1.1] tracking-tight text-paper-50">
                    Six editorial commitments<br>
                    <em class="not-italic text-dispatch-violet">to every reader.</em>
                </h2>
                <p class="mt-4 text-ink-300 text-sm leading-relaxed max-w-lg">
                    Transparency regarding AI involvement may be more critical than the presence of human verification in fostering user trust. Our governance framework — including the AI Nutrition Label and machine-readable C2PA metadata — reflects this research and satisfies EU AI Act Article 50.
                </p>
            </div>

            <div class="mt-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-5">
                <!-- Commitment 1 -->
                <div class="relative border border-white/10 rounded-sm p-5 reveal reveal-delay-1">
                    <span class="commitment-number text-dispatch-ember">1</span>
                    <div class="flex items-center gap-2 mb-3">
                        <span class="w-2 h-2 rounded-full bg-dispatch-ember"></span>
                        <span class="font-mono text-[10px] cat-label text-dispatch-ember font-semibold">Disclosure</span>
                    </div>
                    <h3 class="font-editorial text-lg font-bold text-paper-50 leading-snug">Every summary labeled</h3>
                    <p class="mt-2 text-ink-300 text-xs leading-relaxed">
                        "AI-generated summary using Claude 4.5 Haiku" — prominent, not buried. Disclosure is default, not optional.
                    </p>
                </div>

                <!-- Commitment 2 -->
                <div class="relative border border-white/10 rounded-sm p-5 reveal reveal-delay-2">
                    <span class="commitment-number text-dispatch-sage">2</span>
                    <div class="flex items-center gap-2 mb-3">
                        <span class="w-2 h-2 rounded-full bg-dispatch-sage"></span>
                        <span class="font-mono text-[10px] cat-label text-dispatch-sage font-semibold">Citations</span>
                    </div>
                    <h3 class="font-editorial text-lg font-bold text-paper-50 leading-snug">Sources cited inline</h3>
                    <p class="mt-2 text-ink-300 text-xs leading-relaxed">
                        Every claim maps to the article it was derived from. Click any citation to verify against the original source.
                    </p>
                </div>

                <!-- Commitment 3 -->
                <div class="relative border border-white/10 rounded-sm p-5 reveal reveal-delay-3">
                    <span class="commitment-number text-dispatch-slate">3</span>
                    <div class="flex items-center gap-2 mb-3">
                        <span class="w-2 h-2 rounded-full bg-dispatch-slate"></span>
                        <span class="font-mono text-[10px] cat-label text-dispatch-slate font-semibold">Escape Hatch</span>
                    </div>
                    <h3 class="font-editorial text-lg font-bold text-paper-50 leading-snug">Read original — always</h3>
                    <p class="mt-2 text-ink-300 text-xs leading-relaxed">
                        "Verify with Original Source" is a primary action, never hidden. AI summaries complement articles — they don't replace them.
                    </p>
                </div>

                <!-- Commitment 4 -->
                <div class="relative border border-white/10 rounded-sm p-5 reveal reveal-delay-4">
                    <span class="commitment-number text-dispatch-clay">4</span>
                    <div class="flex items-center gap-2 mb-3">
                        <span class="w-2 h-2 rounded-full bg-dispatch-clay"></span>
                        <span class="font-mono text-[10px] cat-label text-dispatch-clay font-semibold">Confidence</span>
                    </div>
                    <h3 class="font-editorial text-lg font-bold text-paper-50 leading-snug">Coverage visible</h3>
                    <p class="mt-2 text-ink-300 text-xs leading-relaxed">
                        Every summary shows a confidence/coverage indicator — how much of the original article was available to the model.
                    </p>
                </div>

                <!-- Commitment 5 -->
                <div class="relative border border-white/10 rounded-sm p-5 reveal reveal-delay-5">
                    <span class="commitment-number text-dispatch-violet">5</span>
                    <div class="flex items-center gap-2 mb-3">
                        <span class="w-2 h-2 rounded-full bg-dispatch-violet"></span>
                        <span class="font-mono text-[10px] cat-label text-dispatch-violet font-semibold">Nutrition Label</span>
                    </div>
                    <h3 class="font-editorial text-lg font-bold text-paper-50 leading-snug">"What the AI did"</h3>
                    <p class="mt-2 text-ink-300 text-xs leading-relaxed">
                        Every summary carries a plain-language statement of what the AI did, model used, tokens consumed, and coverage percentage. No hidden details.
                    </p>
                </div>

                <!-- Commitment 6 -->
                <div class="relative border border-white/10 rounded-sm p-5 reveal reveal-delay-5">
                    <span class="commitment-number text-dispatch-ember">6</span>
                    <div class="flex items-center gap-2 mb-3">
                        <span class="w-2 h-2 rounded-full bg-dispatch-ember"></span>
                        <span class="font-mono text-[10px] cat-label text-dispatch-ember font-semibold">C2PA Metadata</span>
                    </div>
                    <h3 class="font-editorial text-lg font-bold text-paper-50 leading-snug">Machine-readable</h3>
                    <p class="mt-2 text-ink-300 text-xs leading-relaxed">
                        EU AI Act Article 50 compliant: every AI-generated summary includes machine-readable C2PA provenance metadata. Detectable by browser extensions and regulatory audits.
                    </p>
                </div>
            </div>
        </div>
    </section>


    <!-- ═══════════════════════════════════════════════════════════════ -->
    <!-- 13. CTA (Early Access)                                            -->
    <!-- ═══════════════════════════════════════════════════════════════ -->
    <section id="early-access" class="bg-ink-900 border-t border-white/10 py-16 lg:py-20">
        <div class="max-w-dispatch mx-auto px-4 sm:px-6 lg:px-8">
            <div class="max-w-2xl mx-auto text-center reveal">
                <span class="font-mono text-[11px] cat-label-wide text-ink-300 tracking-[.2em]">Early Access</span>
                <h2 class="mt-4 font-editorial text-3xl sm:text-4xl font-bold leading-[1.1] tracking-tight text-paper-50">
                    Join the briefing room.
                </h2>
                <p class="mt-4 text-ink-300 text-sm leading-relaxed">
                    OneStopNews is in early access. Enter your email to be notified when we open the doors. No spam, no AI-generated newsletters — just one email when it's ready.
                </p>
                <form class="mt-6 flex flex-col sm:flex-row gap-3 max-w-md mx-auto" onsubmit="handleSignup(event)">
                    <label for="email-input" class="sr-only">Email address</label>
                    <input
                        id="email-input"
                        type="email"
                        required
                        placeholder="your@email.com"
                        class="cta-input flex-1 px-4 py-2.5 rounded-sm font-sans text-sm"
                        aria-label="Email address for early access"
                    >
                    <button type="submit" class="bg-paper-50 text-ink-900 px-5 py-2.5 rounded-sm font-medium text-sm hover:bg-paper-100 transition-colors 150ms whitespace-nowrap">
                        Request Access
                    </button>
                </form>
                <p id="signup-success" class="mt-3 text-dispatch-sage text-sm font-medium hidden">
                    <i data-lucide="check-circle" class="w-4 h-4 inline-block mr-1"></i>
                    You're on the list. We'll be in touch.
                </p>
            </div>
        </div>
    </section>


    <!-- ═══════════════════════════════════════════════════════════════ -->
    <!-- 14. FOOTER                                                        -->
    <!-- ═══════════════════════════════════════════════════════════════ -->
    <footer class="bg-ink-900 border-t border-white/10 py-10">
        <div class="max-w-dispatch mx-auto px-4 sm:px-6 lg:px-8">
            <hr class="dispatch-rule-ink mb-8">

            <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8">
                <!-- Brand -->
                <div class="col-span-2 md:col-span-1 lg:col-span-1">
                    <span class="font-editorial text-2xl font-bold text-paper-50">OneStopNews</span>
                    <p class="mt-2 text-ink-300 text-xs leading-relaxed">
                        Topic-first news aggregation with source-cited AI summaries and AI Nutrition Label transparency.
                    </p>
                </div>

                <!-- Product -->
                <div>
                    <h4 class="font-mono text-[10px] cat-label-wide text-ink-300 tracking-[.15em] mb-3">Product</h4>
                    <ul class="space-y-1.5 text-xs text-ink-300">
                        <li><a href="#" class="hover:text-paper-50 transition-colors">Top Stories</a></li>
                        <li><a href="#" class="hover:text-paper-50 transition-colors">AI Summaries</a></li>
                        <li><a href="#" class="hover:text-paper-50 transition-colors">Push Notifications</a></li>
                        <li><a href="#" class="hover:text-paper-50 transition-colors">Search</a></li>
                        <li><a href="#" class="hover:text-paper-50 transition-colors">Categories</a></li>
                    </ul>
                </div>

                <!-- Company -->
                <div>
                    <h4 class="font-mono text-[10px] cat-label-wide text-ink-300 tracking-[.15em] mb-3">Company</h4>
                    <ul class="space-y-1.5 text-xs text-ink-300">
                        <li><a href="#" class="hover:text-paper-50 transition-colors">About</a></li>
                        <li><a href="#" class="hover:text-paper-50 transition-colors">Blog</a></li>
                        <li><a href="#" class="hover:text-paper-50 transition-colors">Careers</a></li>
                        <li><a href="#" class="hover:text-paper-50 transition-colors">Contact</a></li>
                    </ul>
                </div>

                <!-- Legal -->
                <div>
                    <h4 class="font-mono text-[10px] cat-label-wide text-ink-300 tracking-[.15em] mb-3">Legal</h4>
                    <ul class="space-y-1.5 text-xs text-ink-300">
                        <li><a href="#" class="hover:text-paper-50 transition-colors">Privacy Policy</a></li>
                        <li><a href="#" class="hover:text-paper-50 transition-colors">Terms of Service</a></li>
                        <li><a href="#" class="hover:text-paper-50 transition-colors">AI Governance</a></li>
                        <li><a href="#" class="hover:text-paper-50 transition-colors">EU AI Act Compliance</a></li>
                    </ul>
                </div>

                <!-- Tech Stack -->
                <div>
                    <h4 class="font-mono text-[10px] cat-label-wide text-ink-300 tracking-[.15em] mb-3">Built With</h4>
                    <ul class="space-y-1.5 text-xs text-ink-300">
                        <li>Next.js 16.2</li>
                        <li>React 19.2</li>
                        <li>Tailwind CSS v4</li>
                        <li>PostgreSQL 17</li>
                        <li>BullMQ + Redis</li>
                        <li>Claude 4.5 Haiku</li>
                    </ul>
                </div>
            </div>

            <hr class="dispatch-rule-ink my-6">

            <div class="flex flex-col sm:flex-row items-center justify-between gap-3">
                <p class="font-mono text-[10px] text-ink-600">
                    &copy; 2026 OneStopNews. All rights reserved.
                </p>
                <div class="flex items-center gap-4">
                    <span class="flex items-center gap-1.5 font-mono text-[10px] text-ink-600">
                        <span class="w-1.5 h-1.5 rounded-full bg-dispatch-ember pulse-dot"></span>
                        All systems operational
                    </span>
                    <span class="font-mono text-[10px] text-ink-600">v1.0.0-beta</span>
                </div>
            </div>
        </div>
    </footer>


    <!-- ═══════════════════════════════════════════════════════════════ -->
    <!-- JAVASCRIPT                                                        -->
    <!-- ═══════════════════════════════════════════════════════════════ -->
    <script>
        // ─────────────────────────────────────────────────────────────
        // Initialize Lucide icons
        // ─────────────────────────────────────────────────────────────
        document.addEventListener('DOMContentLoaded', function() {
            if (typeof lucide !== 'undefined') {
                lucide.createIcons();
            }
        });

        // ─────────────────────────────────────────────────────────────
        // Tab switching (AI Summary / Original Excerpt)
        // ─────────────────────────────────────────────────────────────
        function switchTab(tab) {
            const summaryPanel = document.getElementById('panel-summary');
            const excerptPanel = document.getElementById('panel-excerpt');
            const summaryTab   = document.getElementById('tab-summary');
            const excerptTab   = document.getElementById('tab-excerpt');

            if (tab === 'summary') {
                summaryPanel.classList.remove('hidden');
                excerptPanel.classList.add('hidden');
                summaryTab.classList.add('active');
                summaryTab.classList.remove('text-ink-400');
                summaryTab.classList.add('text-ink-900');
                excerptTab.classList.remove('active');
                excerptTab.classList.add('text-ink-400');
                excerptTab.classList.remove('text-ink-900');
            } else {
                excerptPanel.classList.remove('hidden');
                summaryPanel.classList.add('hidden');
                excerptTab.classList.add('active');
                excerptTab.classList.remove('text-ink-400');
                excerptTab.classList.add('text-ink-900');
                summaryTab.classList.remove('active');
                summaryTab.classList.add('text-ink-400');
                summaryTab.classList.remove('text-ink-900');
            }
        }

        // ─────────────────────────────────────────────────────────────
        // Accordion (About This Summary — now integrated into Nutrition Label)
        // ─────────────────────────────────────────────────────────────
        function toggleAccordion() {
            const content  = document.getElementById('accordion-content');
            const chevron  = document.getElementById('accordion-chevron');
            const toggle   = document.getElementById('accordion-toggle');

            if (!content || !chevron || !toggle) return;

            content.classList.toggle('open');
            chevron.style.transform = content.classList.contains('open') ? 'rotate(180deg)' : 'rotate(0)';
            toggle.setAttribute('aria-expanded', content.classList.contains('open'));
        }

        // ─────────────────────────────────────────────────────────────
        // Category Navigation (Active State)
        // ─────────────────────────────────────────────────────────────
        document.addEventListener('DOMContentLoaded', function() {
            const catBtns = document.querySelectorAll('.cat-nav-btn');
            catBtns.forEach(function(btn) {
                btn.addEventListener('click', function() {
                    catBtns.forEach(function(b) {
                        b.classList.remove(
                            'border-dispatch-ember', 'border-dispatch-sage',
                            'border-dispatch-slate', 'border-dispatch-clay',
                            'border-dispatch-violet'
                        );
                        b.classList.add('border-transparent');
                        b.classList.remove(
                            'text-ink-900',
                            'bg-dispatch-ember-light/50', 'bg-dispatch-sage-light/40',
                            'bg-dispatch-slate-light/40', 'bg-dispatch-clay-light/40',
                            'bg-dispatch-violet-light/40'
                        );
                        b.classList.add('text-ink-600');
                        b.setAttribute('aria-selected', 'false');
                    });

                    const dot = btn.querySelector('span:first-child');
                    const colorClass = Array.from(dot.classList).find(function(c) {
                        return c.startsWith('bg-dispatch-');
                    });
                    const colorName  = colorClass ? colorClass.replace('bg-dispatch-', '') : 'ember';
                    const lightClass = 'bg-dispatch-' + colorName + '-light/50';

                    btn.classList.remove('border-transparent', 'text-ink-600');
                    btn.classList.add('border-dispatch-' + colorName, 'text-ink-900', lightClass);
                    btn.setAttribute('aria-selected', 'true');
                });
            });
        });

        // ─────────────────────────────────────────────────────────────
        // Sort Buttons (Latest / Impact / Summarized)
        // ─────────────────────────────────────────────────────────────
        document.addEventListener('DOMContentLoaded', function() {
            const sortBtns = document.querySelectorAll('.sort-btn');
            sortBtns.forEach(function(btn) {
                btn.addEventListener('click', function() {
                    sortBtns.forEach(function(b) {
                        b.classList.remove('active');
                        b.setAttribute('aria-pressed', 'false');
                    });
                    btn.classList.add('active');
                    btn.setAttribute('aria-pressed', 'true');
                });
            });
        });

        // ─────────────────────────────────────────────────────────────
        // Scroll Reveal (Intersection Observer)
        // ─────────────────────────────────────────────────────────────
        document.addEventListener('DOMContentLoaded', function() {
            const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

            if (prefersReducedMotion) {
                document.querySelectorAll('.reveal').forEach(function(el) {
                    el.classList.add('visible');
                });
                var fill = document.getElementById('confidence-fill');
                if (fill) fill.classList.add('animate');
                return;
            }

            const observer = new IntersectionObserver(function(entries) {
                entries.forEach(function(entry) {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('visible');
                        observer.unobserve(entry.target);
                    }
                });
            }, {
                threshold: 0.1,
                rootMargin: '0px 0px -40px 0px'
            });

            document.querySelectorAll('.reveal').forEach(function(el) {
                observer.observe(el);
            });

            // Confidence bar animation
            var confidenceObserver = new IntersectionObserver(function(entries) {
                entries.forEach(function(entry) {
                    if (entry.isIntersecting) {
                        var fill = document.getElementById('confidence-fill');
                        if (fill) {
                            setTimeout(function() { fill.classList.add('animate'); }, 200);
                        }
                        confidenceObserver.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.3 });

            var confidenceSection = document.getElementById('confidence-section');
            if (confidenceSection) {
                confidenceObserver.observe(confidenceSection);
            }
        });

        // ─────────────────────────────────────────────────────────────
        // Email Signup (Mock)
        // ─────────────────────────────────────────────────────────────
        function handleSignup(event) {
            event.preventDefault();
            var input   = document.getElementById('email-input');
            var success = document.getElementById('signup-success');
            if (input && input.value) {
                success.classList.remove('hidden');
                input.value = '';
                if (typeof lucide !== 'undefined') {
                    lucide.createIcons();
                }
            }
        }
    </script>

</body>
</html>
```

---

## What Changed — Section-by-Section Map

| # | Section | Original | v3.1 Re-Imagined |
|---|---|---|---|
| 1 | **Wire Ticker** | signal-amber, Space Grotesk content | dispatch-ember, "EU AI Act" reference, Commit Mono |
| 2 | **Masthead** | Instrument Serif wordmark | **Newsreader** wordmark, Instrument Sans tagline |
| 3 | **Category Nav** | signal-* dots, Space Grotesk labels | dispatch-* dots, Instrument Sans labels |
| 4 | **Lead Story** | signal-amber breaking badge | dispatch-ember breaking badge, "See AI Summary" link pointing to Nutrition Label |
| 5 | **Trending Bar** | *Did not exist* | **NEW** — 5-card horizontal scroll, eye icons with reader counts, dispatch-* accents, Live pulse dot |
| 6 | **Story Grid** | Asymmetric col-span, no alignment guarantee | **CSS Subgrid** — `grid-template-rows: subgrid` on every card, "AI Brief" badge on cards with summaries, Commit Mono metadata |
| 7 | **Concept Intro** | "See How It Works" CTA | "See the AI Nutrition Label" CTA, text references AI Nutrition Label |
| 8 | **AI Summary Demo** | Basic accordion, Claude 3.5 Haiku, no EU AI Act | **Full AI Nutrition Label** — "What the AI did" statement, EU AI Act Article 50 badge, Claude 4.5 Haiku, coverage %, C2PA mention, "Report" flag button |
| 9 | **Push Notifications** | *Did not exist* | **NEW** — Phone mockup with two notification cards showing AI-summarised alerts, feature checklist, "40%+ opt-in rate" stat |
| 10 | **How It Works** | "Distill" step generic | "Distill" step mentions Claude 4.5 Haiku, AI Nutrition Label, EU AI Act |
| 11 | **Search & Perf** | Next.js 16 reference | Next.js 16.2, React 19.2 View Transitions mention |
| 12 | **Trust (Ink)** | Five commitments, signal-amber Disclosure | **Six commitments** — added "C2PA Metadata" as 6th commitment with EU AI Act Article 50 language, dispatch-ember for Disclosure |
| 13 | **Early Access** | Same structure | Updated typography only |
| 14 | **Footer** | "Claude 3.5 Haiku" not listed | "Claude 4.5 Haiku" in tech stack, "EU AI Act Compliance" legal link, "Push Notifications" product link |
| **Head** | No provenance meta | `<meta name="ai-provenance">` for C2PA machine-readable compliance |

---

## Quality Assurance Verification

| Check | Status |
|---|---|
| All typefaces: Newsreader + Instrument Sans + Commit Mono | ✅ |
| All accent colors: dispatch-ember/sage/slate/clay/violet | ✅ |
| No signal-* references remain | ✅ |
| AI model: Claude 4.5 Haiku | ✅ |
| EU AI Act Article 50 referenced | ✅ |
| Machine-readable provenance in `<head>` | ✅ |
| CSS Subgrid on story cards | ✅ |
| "AI Brief" badges on cards with summaries | ✅ |
| Trending Bar section present | ✅ |
| Push Notification Showcase present | ✅ |
| AI Nutrition Label with "What the AI did" | ✅ |
| 6 Trust Commitments (not 5) | ✅ |
| `prefers-reduced-motion` respected | ✅ |
| All ARIA attributes preserved | ✅ |
| C2PA metadata mentioned | ✅ |
| No hardcoded Inter, Roboto, Space Grotesk | ✅ |

# https://chat.deepseek.com/share/xl0ddndoz64xllneqb 
