# OneStopNews Landing Page — Comprehensive Design Plan

> **Agent Role:** Claw Code — Frontend Architect & Avant-Garde UI Designer
> **Workflow:** ANALYZE → PLAN → VALIDATE → IMPLEMENT → VERIFY → DELIVER
> **Design Skill:** super-frontend-design (10-skill master)
> **Source PRD:** OneStopNews Refined PRD v2.0
> **Reference:** Existing static HTML implementation (sample_landing_page_to_re-imagine.html)
> **Date:** 2026-06-09

---

# PHASE 1: ANALYZE — Deep Requirement Mining

---

## 1.1 Intentionality Compass

| Question | Analysis | Compass Direction |
|----------|----------|-------------------|
| **Primary fear?** | "Wasting time on scattered, unreliable news" + "Not knowing if AI summaries are trustworthy" | **Institutional Clarity** — reduce cognitive load AND signal trustworthiness |
| **Decision style?** | Rational but overwhelmed by volume; seeks structure but wants comprehensiveness | **Institutional Clarity** — provide structured clarity with transparent AI governance |
| **Trust source?** | Credible outlets, verifiable sources, transparent AI disclosure | **Institutional Clarity** — signal provenance and source-cited transparency |
| **Category relationship?** | New approach (topic-first vs outlet-first); needs reassurance this is better | **Institutional Clarity** — build confidence through editorial weight and AI transparency |

**Result: Q1 — THE GUARDIAN** (with Dynamic Modernism accents in AI summary interactions)

> Rationale: The audience is risk-averse (news readers need accuracy) but the product itself has innovative AI features. The base aesthetic must signal trust, editorial rigor, and institutional weight. The AI summary interactions can inject Dynamic Modernism — making the innovative features feel cutting-edge while the editorial wrapper feels timeless.

---

## 1.2 Anti-Generic Litmus Test

| Decision | Why? | Only? | Without? |
|----------|------|-------|----------|
| **"Ink & Signal" aesthetic** | Combines analog editorial gravitas (ink) with digital precision (signal) for a news+AI product | No other news aggregator uses this specific tension — most are either fully traditional (BBC) or fully modern (Flipboard) | It becomes either a stodgy newspaper site or another generic tech dashboard |
| **Wire ticker as first element** | Sets "briefing room" tone instantly; signals real-time operational seriousness | No landing page in the news category leads with a wire ticker — they all use hero images or value props | The "live, operational" feeling is lost; feels like a blog |
| **Lead story IS the hero** | News readers want news, not marketing copy; shows the product immediately | Most news products bury content behind onboarding — this inverts that pattern | Becomes a generic SaaS landing page with "Features" and "How It Works" before showing value |
| **Asymmetric editorial grid** | Editorial feel — different visual weights communicate hierarchy like a print newspaper | Symmetric bento grids are the 2025-2026 AI-generated cliché; this deliberately rejects that | Loses the print-newspaper gravitas; becomes another card grid |
| **Source-cited AI demo as centerpiece** | Trust research shows disclosure + citations counteract AI skepticism; this demonstrates it interactively | Most AI products hide their process; showing the citation system is differentiation | The trust-building mechanism is described but not demonstrated |

---

## 1.3 Competitive Differentiation Analysis

| Competitor | Their Approach | Our Differentiation |
|------------|---------------|---------------------|
| **Google News** | Algorithmic, card-based, generic | We are editorially curated with explicit topic hierarchy and AI transparency |
| **Apple News+** | Glossy magazine aesthetic, publisher-focused | We are topic-first (not publisher-first) with source-cited AI summaries |
| **Flipboard** | Social magazine, image-heavy, casual | We are serious briefing-room, wire-service density, enterprise-grade |
| **Feedly** | RSS power tool, utilitarian, dense | We are consumer-friendly with AI summarization and editorial curation |
| **Perplexity** | AI-native, conversational, Q&A | We are topic-browsing, editorially structured, not chat-based |

**Our moat:** The only news product that combines topic-first editorial structure with source-cited AI transparency, wrapped in an "Ink & Signal" aesthetic that feels simultaneously timeless (editorial) and cutting-edge (AI governance).

---

## 1.4 Technical Constraints & Commitments

| Constraint | Decision | Rationale |
|------------|----------|-----------|
| **Format** | Single static HTML file | Maximum portability; immediate browser preview; zero build step |
| **Dependencies** | Google Fonts + Tailwind CSS v4 CDN + Lucide icons CDN | Zero build tools; fastest time-to-preview |
| **CSS approach** | Tailwind v4 `@theme` directives in embedded `<style>` | CSS-first tokens; design system embedded |
| **JS approach** | Vanilla JS, no frameworks | Single file; no bundler needed; Intersection Observer for scroll animations |
| **Images** | `picsum.photos` seeded URLs for demo content | Consistent, repeatable placeholder images |
| **Performance target** | <200KB total (excluding external fonts/CDN) | Fast load; single file advantage |
| **Accessibility target** | WCAG AAA for body text; AA minimum for all elements | Federally required (ADA Title II, April 2026) |

---

## 1.5 Risk Assessment

| Risk | Likelihood | Mitigation |
|------|------------|------------|
| Existing sample feels "done enough" | High | Clearly articulate what the enhanced version adds: scroll animations, refined typography, interactive confidence bar, improved color system |
| Single-file constraint limits capability | Medium | Push the format to its limit — embedded SVG patterns, CSS animations, Intersection Observer |
| "Ink & Signal" direction may feel too dark | Low | Keep paper-50 background as dominant; ink is for text and one section only |
| AI summary demo complexity | Medium | Implement in phases: tabs first, then accordion, then confidence bar animation |

---

# PHASE 2: PLAN — Structured Execution Roadmap

---

## 2.1 Evolved Conceptual Direction: "Ink & Signal"

The existing implementation uses a warm editorial aesthetic ("Editorial Dispatch"). The evolved direction — **"Ink & Signal"** — heightens the tension between analog editorial gravitas and digital precision:

- **Ink** = The timeless weight of printed news: deep blacks, editorial serifs, structured grids, thick rules, high contrast
- **Signal** = The precision of digital information: monospace metadata, confidence indicators, live pulses, color-coded categories, interactive transparency

This tension is the product's identity: **trustworthy editorial judgment enhanced by transparent AI assistance.**

---

## 2.2 Design Token System (Evolved)

### Color Tokens

| Token | Value | OKLCH Equivalent | Purpose |
|-------|-------|-----------------|---------|
| `--ink-900` | `#0A0A0A` | `oklch(0.05 0 0)` | Primary headlines, dark backgrounds |
| `--ink-700` | `#262626` | `oklch(0.25 0 0)` | Secondary headings |
| `--ink-500` | `#525252` | `oklch(0.45 0 0)` | Body text |
| `--ink-300` | `#A3A3A3` | `oklch(0.70 0 0)` | Muted metadata |
| `--ink-200` | `#D4D4D4` | `oklch(0.85 0 0)` | Subtle borders |
| `--paper-50` | `#FAFAF8` | `oklch(0.98 0.01 80)` | Page background (warm) |
| `--paper-100` | `#F0EEE8` | `oklch(0.94 0.02 80)` | Card surfaces |
| `--paper-200` | `#E2DDD5` | `oklch(0.88 0.03 80)` | Borders, dividers |
| `--signal-amber` | `#B45309` | `oklch(0.55 0.14 60)` | Breaking / Top Stories |
| `--signal-sage` | `#3D6B4F` | `oklch(0.52 0.10 155)` | Finance |
| `--signal-slate` | `#4A5568` | `oklch(0.42 0.05 250)` | Tech / Global |
| `--signal-clay` | `#9C4221` | `oklch(0.48 0.16 45)` | Politics / Local |
| `--signal-violet` | `#5B4C9A` | `oklch(0.45 0.15 285)` | Culture |
| `--signal-rose` | `#9F1239` | `oklch(0.45 0.20 15)` | Live / Urgent |

> **Change from existing:** Deeper ink (was #111111 → now #0A0A0A), richer signal colors with OKLCH-perceptual uniformity, added signal-rose for live indicators. The amber, sage, slate, clay, and violet signals are deepened for higher contrast against paper backgrounds.

### Typography Tokens

| Role | Font | Weight | Size Range | Line Height | Letter Spacing |
|------|------|--------|-----------|-------------|----------------|
| Display H1 | **Instrument Serif** | 400 (italic for emphasis) | 48–72px | 1.05 | -0.02em |
| H2 Section | **Instrument Serif** | 400 | 32–48px | 1.1 | -0.01em |
| H3 Card Title | **Instrument Serif** | 500 | 20–28px | 1.2 | 0 |
| Body | **Space Grotesk** | 400 | 14–16px | 1.6 | 0 |
| UI Labels | **Space Grotesk** | 500 | 12–14px | 1.4 | 0.02em |
| Metadata / Mono | **JetBrains Mono** | 400 | 10–12px | 1.4 | 0.01em |
| Monospace Accents | **JetBrains Mono** | 500 | 11px | 1.2 | 0.1em (small-caps) |

> **Change from existing:** Instrument Serif replaces Newsreader — more distinctive stroke contrast, more editorial gravitas, better italic forms. Space Grotesk and JetBrains Mono retained (they work well).

### Spacing Tokens (8-Point Grid)

| Token | Value | Usage |
|-------|-------|-------|
| `--space-1` | 4px | Tight internal padding |
| `--space-2` | 8px | Inline gaps |
| `--space-3` | 12px | Small component padding |
| `--space-4` | 16px | Standard padding |
| `--space-5` | 20px | Component gaps |
| `--space-6` | 24px | Section internal spacing |
| `--space-8` | 32px | Card padding |
| `--space-10` | 40px | Section padding |
| `--space-12` | 48px | Large section padding |
| `--space-16` | 64px | Section vertical padding |
| `--space-20` | 80px | Major section breaks |
| `--space-24` | 96px | Hero-level spacing |

### Layout Tokens

| Token | Value | Usage |
|-------|-------|-------|
| `--max-width` | 1440px | Content container max-width |
| `--grid-columns` | 12 | Desktop grid system |
| `--gutter` | 24px | Grid gutter |
| `--border-radius-sm` | 2px | Cards, buttons |
| `--border-radius-md` | 4px | Panels |
| `--border-width` | 1px | Standard borders (paper-200) |
| `--border-width-thick` | 2.5px | Section breaks (ink-900) |

---

## 2.3 Page Architecture (12 Sections)

```
┌─────────────────────────────────────────────────────────────┐
│ 1. WIRE TICKER                                              │
│    Dark ink bar, monospace scrolling headlines, LIVE pulse  │
│    Height: 40px, sticky: no, z: 50                          │
├─────────────────────────────────────────────────────────────┤
│ 2. MASTHEAD                                                 │
│    Edition bar (mono, 11px) + wordmark (Instrument Serif)   │
│    Height: auto, border-bottom on edition bar               │
├─────────────────────────────────────────────────────────────┤
│ 3. CATEGORY RIBBON (Sticky)                                 │
│    Signal-colored dots + category labels + story counts     │
│    Position: sticky top-0, z: 40, backdrop-blur             │
├─────────────────────────────────────────────────────────────┤
│ 4. LEAD STORY (The Hero)                                    │
│    Asymmetric 7:5 grid — image + editorial headline block   │
│    Category signal dot, breaking badge, source line         │
├─────────────────────────────────────────────────────────────┤
│ 5. STORY GRID (Asymmetric)                                  │
│    12-col grid: 7-5-4-4-4 card spans, editorial density     │
│    Hover: background shift + subtle lift                    │
├─────────────────────────────────────────────────────────────┤
│ 6. THICK RULE — Newspaper section break                     │
│    2.5px ink-900 horizontal rule, max-width centered        │
├─────────────────────────────────────────────────────────────┤
│ 7. CONCEPT INTRO — "Why OneStopNews"                        │
│    Editorial manifesto: massive serif + emphasized phrase   │
│    Scroll-triggered fade-up reveal                          │
├─────────────────────────────────────────────────────────────┤
│ 8. AI SUMMARY DEMO (Interactive Centerpiece)                │
│    Left: Feature explanation with checkmarks                │
│    Right: Interactive panel — tabs, citations, confidence   │
│    Scroll-triggered confidence bar animation                │
├─────────────────────────────────────────────────────────────┤
│ 9. HOW IT WORKS — 3-Step Pipeline                           │
│    Ingest → Organize → Distill, numbered with dividers      │
│    Scroll-triggered staggered reveal (50ms per item)        │
├─────────────────────────────────────────────────────────────┤
│ 10. SEARCH & SPEED                                          │
│    BM25 search explanation + performance metrics grid       │
│    Mock search bar with ⌘K shortcut hint                    │
├─────────────────────────────────────────────────────────────┤
│ 11. TRUST (INK) — Full-bleed dark section                   │
│    ink-900 background, 5 AI governance commitments          │
│    Color-coded numbered list (amber/sage/slate/clay/violet) │
├─────────────────────────────────────────────────────────────┤
│ 12. CTA + FOOTER                                            │
│    Centered early access signup + editorial 5-col footer    │
│    Tech stack badge: Next.js 16 · PostgreSQL 17 · BullMQ   │
└─────────────────────────────────────────────────────────────┘
```

---

## 2.4 Section-by-Section Design Specifications

### Section 1: Wire Ticker

| Property | Specification |
|----------|--------------|
| **Background** | `ink-900` (#0A0A0A) |
| **Text** | `paper-100` (#F0EEE8), JetBrains Mono, 11px |
| **Height** | 40px fixed |
| **Animation** | Infinite horizontal scroll, 80s linear, pause on hover |
| **Content** | 6 breaking headlines duplicated for seamless loop, each prefixed with signal-colored category label |
| **Separators** | `paper-300` pipe character (│) between items |
| **ARIA** | `role="marquee"`, `aria-label="Breaking news ticker"` |
| **Reduced motion** | Animation disabled; content shown as static wrap |

### Section 2: Masthead

| Property | Specification |
|----------|--------------|
| **Background** | `paper-50` |
| **Border** | Bottom 1px `paper-200` |
| **Edition bar** | Flex row, justify-between, py-2.5, mono 11px, `ink-300` |
| **Left** | "Edition 1.0" + date |
| **Right** | Live pulse dot (signal-rose, 2s pulse) + "SGT" timestamp |
| **Wordmark** | Centered, Instrument Serif, 4xl/5xl/6xl responsive, font-weight 400, tracking-tight |
| **Tagline** | JetBrains Mono, 12px, `ink-300`, small-caps, tracking-[0.2em] |

### Section 3: Category Ribbon (Sticky)

| Property | Specification |
|----------|--------------|
| **Position** | Sticky top-0 |
| **Z-index** | 40 |
| **Background** | `paper-50/95` with backdrop-blur-sm |
| **Border** | Bottom 1px `paper-200` |
| **Layout** | Flex row, gap-1, overflow-x-auto, scrollbar hidden |
| **Active tab** | Signal-colored bottom border (2px) + light tint background |
| **Inactive tab** | Transparent border, `ink-500` text, hover: `ink-900` + `paper-100` bg |
| **Tab content** | Signal dot (8px circle) + category name + story count (mono 10px) |
| **ARIA** | `role="tablist"`, each tab `role="tab"`, `aria-selected` toggled |

### Section 4: Lead Story

| Property | Specification |
|----------|--------------|
| **Layout** | 12-column grid: image 7 cols, text 5 cols |
| **Category label** | Signal dot (10px) + mono category path (11px, signal-colored) |
| **Image** | aspect-[16/9] lg:aspect-[16/10], object-cover, `paper-200` placeholder bg |
| **Breaking badge** | Absolute positioned top-left, signal-amber bg, white text, pulse dot |
| **Headline** | Instrument Serif, 3xl/4xl/[42px], leading-[1.1], tracking-tight, `ink-900` |
| **Meta line** | Flex wrap, mono 11px, `ink-300`: sources · time · source count |
| **Excerpt** | Space Grotesk, 15px, `ink-500`, leading-relaxed |
| **CTA row** | AI Summary badge (sage) + "Read Original" link |

### Section 5: Story Grid (Asymmetric)

| Property | Specification |
|----------|--------------|
| **Grid** | 12-column, gap-5: Card 1 (7), Card 2 (5), Cards 3-5 (4 each) |
| **Card style** | Border 1px `paper-200`, border-radius-sm, p-4/p-5, cursor-pointer |
| **Card hover** | Background → `paper-100`, translateY(-2px), shadow-sm, 180ms ease |
| **Card internals** | Signal dot + category label → headline → excerpt (optional) → meta line |
| **Image cards** | Some cards have right-side image (5-col internal grid) |
| **Sort controls** | "Latest Stories" label + Latest/Impact/Summarized toggle buttons |

### Section 6: Thick Rule

| Property | Specification |
|----------|--------------|
| **Style** | 2.5px solid `ink-900`, no margin, max-width centered |
| **Purpose** | Visual section break — newspaper editorial convention |

### Section 7: Concept Intro

| Property | Specification |
|----------|--------------|
| **Layout** | Left-aligned, max-width 3xl |
| **Eyebrow** | Mono 11px, `ink-300`, small-caps, tracking-[0.2em] |
| **Headline** | Instrument Serif, 3xl/4xl/5xl, leading-[1.1] |
| **Emphasis** | Italic Instrument Serif, signal-slate color for key phrase |
| **Body** | Space Grotesk, base/lg, `ink-500`, max-width xl |
| **Animation** | Scroll-triggered: opacity 0→1, translateY(30px→0), 600ms, ease-out |

### Section 8: AI Summary Demo (Interactive Centerpiece)

| Property | Specification |
|----------|--------------|
| **Layout** | 12-column grid: explanation (4 cols) + demo panel (8 cols) |
| **Background** | `paper-100`, border-y 1px `paper-200` |
| **Left panel** | Eyebrow (sage) → headline → description → 4 feature checkmarks |
| **Right panel** | White card with border + shadow |
| **Tab bar** | "AI Summary" / "Original Excerpt" tabs + "AI-Generated" badge |
| **Tab indicator** | Animated underline (width 0→100%, 200ms ease) |
| **Summary content** | Body text with inline citation refs (dashed underline, violet) |
| **Key points** | Bulleted list with em-dash + signal-slate bullets |
| **Citations section** | Numbered sources with violet numbers, linked titles |
| **Confidence bar** | 3px height, `paper-200` track, sage fill, animated width on scroll |
| **Accordion** | "About This Summary" — chevron rotation + max-height expand |
| **Excerpt panel** | Italic quoted text, source line, "Read Full Article" link |

### Section 9: How It Works

| Property | Specification |
|----------|--------------|
| **Layout** | 3-column grid, gap-8/12 |
| **Eyebrow** | Mono 11px, `ink-300`, small-caps |
| **Step number** | Mono 11px, `ink-300`, semibold |
| **Divider** | 1px `paper-200`, flex-1 between number and content |
| **Step title** | Instrument Serif, 2xl, bold, `ink-900` |
| **Description** | Space Grotesk, sm, `ink-500`, leading-relaxed |
| **Tech details** | Mono 10px, `ink-300`, stacked lines |
| **Animation** | Staggered scroll reveal: 50ms delay between steps |

### Section 10: Search & Speed

| Property | Specification |
|----------|--------------|
| **Layout** | 2-column grid, gap-12 |
| **Background** | `paper-100`, border-y 1px `paper-200` |
| **Search side** | Eyebrow → headline → description → mock search bar |
| **Search bar** | White bg, border, search icon, input, ⌘K hint |
| **Performance side** | Eyebrow → headline → description → 3-stat grid |
| **Stats** | Instrument Serif 3xl values + mono 10px labels |
| **Stats** | <800ms FCP · <1.5s LCP · 95%+ Freshness |

### Section 11: Trust (Ink Section)

| Property | Specification |
|----------|--------------|
| **Background** | `ink-900` full-bleed |
| **Text** | `paper-50` primary, `paper-300` secondary |
| **Layout** | 12-column: left text (5 cols) + commitments (7 cols) |
| **Eyebrow** | Mono 11px, `paper-300`, small-caps |
| **Headline** | Instrument Serif, 3xl/4xl, `paper-50`, sage-colored emphasis |
| **Commitments** | 5 numbered items, each with signal-colored number + heading + description |
| **Separators** | Border-bottom `ink-700` between items |
| **Animation** | Scroll-triggered staggered reveal |

### Section 12: CTA + Footer

| Property | CTA Specification |
|----------|-------------------|
| **Layout** | Centered, max-width 2xl |
| **Eyebrow** | Mono 11px, `ink-300`, small-caps |
| **Headline** | Instrument Serif, 3xl/4xl/5xl |
| **Body** | Space Grotesk, base, `ink-500`, max-width md |
| **Form** | Email input + "Request Access" button, flex row sm |
| **Button** | `ink-900` bg, `paper-50` text, hover: `ink-700`, min-h-[44px] |

| Property | Footer Specification |
|----------|----------------------|
| **Background** | `paper-100`, border-t `paper-200` |
| **Layout** | 5-column grid (brand + 4 link columns) |
| **Brand** | Instrument Serif xl, tagline |
| **Columns** | Product, Categories (with signal dots), Company |
| **Bottom bar** | Copyright + tech stack badge |

---

## 2.5 Animation Strategy (Purposeful Motion Only)

| Element | Animation | Duration | Easing | Trigger |
|---------|-----------|----------|--------|---------|
| **Ticker** | translateX(0 → -50%), infinite | 80s | linear | Page load |
| **LIVE dot** | opacity 1 ↔ 0.35 | 2s | ease-in-out | Infinite loop |
| **Section reveals** | opacity 0→1, translateY(30px→0) | 600ms | `cubic-bezier(0.4, 0, 0.2, 1)` | Intersection Observer |
| **Staggered items** | Same as above, sequential | 600ms + 50ms stagger | Same | Intersection Observer |
| **Card hover** | translateY(-2px), shadow-sm | 180ms | ease-out | Mouseenter |
| **Card hover bg** | background-color transition | 180ms | ease | Mouseenter |
| **Tab switch** | Underline width 0→100% | 200ms | `cubic-bezier(0.4, 0, 0.2, 1)` | Click |
| **Tab content** | display toggle (instant) | 0ms | none | Click |
| **Confidence bar** | width 0%→87% | 800ms | `cubic-bezier(0.4, 0, 0.2, 1)` | Intersection Observer |
| **Accordion** | max-height 0→400px, chevron rotate | 300ms | `cubic-bezier(0.4, 0, 0.2, 1)` | Click |
| **Citation hover** | background-color tint | 150ms | ease | Mouseenter |
| **Nav tab hover** | color + background transition | 150ms | ease | Mouseenter |
| **Button hover** | background-color shift | 150ms | ease | Mouseenter |
| **Focus states** | 2px violet outline, 2px offset | instant | none | Focus-visible |

### Scroll Reveal Implementation (Intersection Observer)

```javascript
// Pattern: Add .revealed class when element enters viewport
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('revealed');
      observer.unobserve(entry.target); // One-shot
    }
  });
}, { threshold: 0.15, rootMargin: '0px 0px -50px 0px' });
```

```css
/* Base state */
.reveal-on-scroll {
  opacity: 0;
  transform: translateY(30px);
}
/* Revealed state */
.reveal-on-scroll.revealed {
  opacity: 1;
  transform: translateY(0);
  transition: opacity 600ms cubic-bezier(0.4, 0, 0.2, 1),
              transform 600ms cubic-bezier(0.4, 0, 0.2, 1);
}
/* Staggered children */
.reveal-on-scroll.revealed .stagger-child:nth-child(1) { transition-delay: 0ms; }
.reveal-on-scroll.revealed .stagger-child:nth-child(2) { transition-delay: 50ms; }
.reveal-on-scroll.revealed .stagger-child:nth-child(3) { transition-delay: 100ms; }
```

### Reduced Motion Compliance

```css
@media (prefers-reduced-motion: reduce) {
  .ticker-track { animation: none; }
  .pulse-dot { animation: none; }
  .reveal-on-scroll { opacity: 1; transform: none; }
  .reveal-on-scroll.revealed { transition: none; }
  .confidence-fill { transition: none; }
  * { 
    animation-duration: 0ms !important;
    transition-duration: 0ms !important;
  }
}
```

---

## 2.6 Component Architecture

### Tailwind v4 @theme Configuration

```css
@theme {
  /* Colors */
  --color-ink-900: #0A0A0A;
  --color-ink-700: #262626;
  --color-ink-500: #525252;
  --color-ink-300: #A3A3A3;
  --color-ink-200: #D4D4D4;
  --color-paper-50: #FAFAF8;
  --color-paper-100: #F0EEE8;
  --color-paper-200: #E2DDD5;
  --color-signal-amber: #B45309;
  --color-signal-sage: #3D6B4F;
  --color-signal-slate: #4A5568;
  --color-signal-clay: #9C4221;
  --color-signal-violet: #5B4C9A;
  --color-signal-rose: #9F1239;

  /* Typography */
  --font-editorial: 'Instrument Serif', Georgia, serif;
  --font-sans: 'Space Grotesk', system-ui, sans-serif;
  --font-mono: 'JetBrains Mono', monospace;

  /* Custom max-width */
  --max-width-dispatch: 1440px;
}
```

### Google Fonts Loading Strategy

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Space+Grotesk:wght@300..700&family=JetBrains+Mono:ital,wght@0,400;0,500;0,600;1,400&display=swap" rel="stylesheet">
```

> **Font loading:** `display=swap` for fast initial render. Instrument Serif loaded at 400 weight only (it's a display face; we don't need 700). Space Grotesk at full range (300-700). JetBrains Mono at 400, 500, 600.

### Lucide Icons (CDN)

```html
<script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
<script>lucide.createIcons();</script>
```

**Icons used:**
- `users` — source attribution
- `file-text` — article count
- `sparkles` — AI summary indicator
- `arrow-up-right` — external link
- `search` — search bar
- `chevron-down` — accordion toggle

---

## 2.7 Accessibility Strategy

| Requirement | Implementation |
|-------------|----------------|
| **WCAG AAA contrast** | All body text: `ink-500` (#525252) on `paper-50` (#FAFAF8) = ~7.2:1 ✓ |
| **Headline contrast** | `ink-900` (#0A0A0A) on `paper-50` = ~18:1 ✓ |
| **Dark section contrast** | `paper-50` on `ink-900` = ~18:1 ✓ |
| **Touch targets** | All buttons ≥44px height; nav tabs padded appropriately |
| **Focus states** | Global `:focus-visible` — 2px `signal-violet` outline, 2px offset |
| **Semantic HTML** | `<header>`, `<nav>`, `<section>`, `<article>`, `<footer>` |
| **ARIA** | `role="tablist"`, `role="tab"`, `aria-selected`, `aria-label` on all interactive elements |
| **Reduced motion** | All animations disabled via `prefers-reduced-motion: reduce` |
| **Keyboard nav** | All interactive elements keyboard-accessible; tab order logical |

---

## 2.8 Responsive Breakpoints

| Breakpoint | Width | Layout Changes |
|------------|-------|----------------|
| **Mobile** | < 640px | Single column, stacked layout, horizontal-scroll category nav, bottom padding for nav, full-width cards |
| **Tablet** | 640–1023px | 2-column grids, collapsible sidebar concepts, medium padding |
| **Desktop** | 1024–1279px | Full 12-column grid, side-by-side layouts, max padding |
| **Wide** | ≥ 1280px | Full 12-column grid at max-width 1440px centered |

---

## 2.9 Implementation Order (Phase 4 Sub-phases)

```
Sub-phase 4.1: Foundation
├── HTML5 boilerplate with meta tags
├── Google Fonts preconnect + loading
├── Tailwind v4 CDN + @theme configuration
├── Lucide icons CDN
├── Global CSS resets and custom properties
├── Selection styling (::selection)
└── Reduced motion media query

Sub-phase 4.2: Static Sections (top to bottom)
├── Section 1: Wire Ticker (HTML + CSS animation)
├── Section 2: Masthead (HTML + layout)
├── Section 3: Category Ribbon (HTML + sticky CSS)
├── Section 4: Lead Story (HTML + 12-col grid)
├── Section 5: Story Grid (HTML + asymmetric grid)
├── Section 6: Thick Rule (HTML)
└── Interactivity: Category nav active states (JS)

Sub-phase 4.3: Content Sections
├── Section 7: Concept Intro (HTML + scroll reveal)
├── Section 8: AI Summary Demo (HTML + CSS + full JS interactivity)
│   ├── Tab switching
│   ├── Accordion toggle
│   └── Confidence bar animation
├── Section 9: How It Works (HTML + staggered reveal)
├── Section 10: Search & Speed (HTML)
└── Interactivity: Sort button states (JS)

Sub-phase 4.4: Closing Sections
├── Section 11: Trust/Ink (HTML + scroll reveal)
├── Section 12: CTA + Footer (HTML + form)
└── Interactivity: Scroll reveal system (Intersection Observer)

Sub-phase 4.5: Polish & QA
├── Focus states verification
├── Keyboard navigation test
├── Reduced motion test
├── Responsive breakpoints verification
├── Contrast ratio spot-check
└── Final HTML validation
```

---

# PHASE 3: VALIDATE — Confirmation Checkpoint

---

Before implementation, the following must be confirmed:

## 3.1 Style Tile Summary

| Aspect | Choice |
|--------|--------|
| **Conceptual direction** | "Ink & Signal" — editorial gravitas + digital precision |
| **Display typeface** | Instrument Serif (replaces Newsreader) |
| **Body typeface** | Space Grotesk (retained) |
| **Mono typeface** | JetBrains Mono (retained) |
| **Primary background** | Warm paper-50 (#FAFAF8) |
| **Primary text** | Deep ink-900 (#0A0A0A) |
| **Category system** | 5 signal colors: amber, sage, slate, clay, violet |
| **Accent** | Signal-violet for citations, signal-rose for live indicators |
| **Dark section** | Ink-900 background with paper-50 text |

## 3.2 Contrast Verification (WCAG)

| Combination | Ratio | Level |
|-------------|-------|-------|
| ink-900 (#0A0A0A) on paper-50 (#FAFAF8) | ~18:1 | AAA ✓ |
| ink-500 (#525252) on paper-50 (#FAFAF8) | ~7.2:1 | AAA ✓ |
| ink-300 (#A3A3A3) on paper-50 (#FAFAF8) | ~3.8:1 | AA (for large text only) |
| paper-50 (#FAFAF8) on ink-900 (#0A0A0A) | ~18:1 | AAA ✓ |
| signal-sage (#3D6B4F) on paper-50 | ~4.8:1 | AA ✓ |
| signal-amber (#B45309) on paper-50 | ~4.2:1 | AA ✓ |

## 3.3 Key Design Decisions to Confirm

1. **Instrument Serif over Newsreader** — More distinctive editorial voice, better stroke contrast, superior italic forms
2. **Deeper ink (#0A0A0A vs #111111)** — Higher contrast, more gravitas, better "Ink & Signal" tension
3. **Scroll-triggered reveals** — Purposeful motion serving comprehension; not decorative
4. **Confidence bar animation** — Demonstrates AI transparency (core PRD requirement) in an engaging way
5. **Single-file deliverable** — Zero build tools; open directly in browser

---

**AWAITING USER CONFIRMATION BEFORE PROCEEDING TO PHASE 4: IMPLEMENT**

---

# PHASE 4: IMPLEMENTATION — Technical Specifications

---

> **(This section will be executed after user validation)**

## 4.1 File Structure

```
/mnt/agents/output/
└── onestopnews-landing.html    (single file, ~65-75KB)
```

## 4.2 HTML Architecture

```html
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
  <!-- Meta + SEO -->
  <!-- Preconnect + Fonts -->
  <!-- Tailwind v4 CDN + Config -->
  <!-- Lucide CDN -->
  <!-- Embedded Styles -->
</head>
<body class="bg-paper-50 text-ink-900 font-sans">
  <!-- 1. Wire Ticker -->
  <!-- 2. Masthead -->
  <!-- 3. Category Ribbon -->
  <!-- 4. Lead Story -->
  <!-- 5. Story Grid -->
  <!-- 6. Thick Rule -->
  <!-- 7. Concept Intro -->
  <!-- 8. AI Summary Demo -->
  <!-- 9. How It Works -->
  <!-- 10. Search & Speed -->
  <!-- 11. Trust (Ink) -->
  <!-- 12. CTA + Footer -->
  <!-- JavaScript -->
</body>
</html>
```

## 4.3 JavaScript Functions Required

| Function | Purpose | Lines |
|----------|---------|-------|
| `initLucide()` | Initialize Lucide icons | 1 |
| `switchTab(tabName)` | AI Summary / Original Excerpt toggle | ~15 |
| `toggleAccordion()` | About This Summary expand/collapse | ~8 |
| `initCategoryNav()` | Category ribbon active state management | ~12 |
| `initSortButtons()` | Latest/Impact/Summarized toggle | ~10 |
| `initScrollReveal()` | Intersection Observer for scroll animations | ~20 |
| `initConfidenceBar()` | Trigger confidence bar animation on scroll | ~8 |
| `initReducedMotion()` | Check prefers-reduced-motion, disable animations | ~10 |

**Total JS:** ~84 lines of vanilla JavaScript

## 4.4 CSS Architecture

| Layer | Content | Approx Size |
|-------|---------|-------------|
| **Tailwind @theme** | Custom colors, fonts, spacing tokens | ~30 lines |
| **Global resets** | Font smoothing, selection, focus-visible | ~10 lines |
| **Keyframe animations** | Ticker scroll, pulse dot | ~10 lines |
| **Component utilities** | cat-label, dispatch-rule, story-card, citation-ref, tab-btn | ~30 lines |
| **Scroll reveal system** | .reveal-on-scroll, .revealed, stagger children | ~15 lines |
| **Confidence bar** | Track + fill styling | ~5 lines |
| **Accordion** | max-height transition | ~5 lines |
| **Feature checkmarks** | ::before pseudo-element | ~5 lines |
| **Reduced motion** | @media prefers-reduced-motion | ~8 lines |

**Total CSS:** ~118 lines of embedded styles

---

# PHASE 5: VERIFY — QA Checklist

---

| # | Check | Criteria | Method |
|---|-------|----------|--------|
| 1 | **Anti-Generic** | No bento grids, no purple gradients, no Inter/Roboto, no stock-photo hero, no card-grid cliché | Visual inspection |
| 2 | **Typography Hierarchy** | Squint test passes — clear hierarchy without color at 50% blur | Manual test |
| 3 | **Color Contrast** | All text meets WCAG AA (4.5:1); body text meets AAA (7:1) | Automated spot-check |
| 4 | **Responsive** | Functional at 320px, 768px, 1024px, 1440px+ | Browser dev tools |
| 5 | **Motion Purpose** | Every animation serves comprehension; no decorative motion | Review against animation table |
| 6 | **Reduced Motion** | All animations disabled when prefers-reduced-motion: reduce | System preference toggle |
| 7 | **Interactivity** | Tabs, accordion, category nav, sort buttons all functional | Manual click-through |
| 8 | **Semantic HTML** | Proper landmarks, heading hierarchy, ARIA labels | W3C validator |
| 9 | **Keyboard Nav** | All interactive elements reachable via Tab; logical order | Keyboard-only test |
| 10 | **Focus States** | Visible focus indicator on all interactive elements | Tab through page |
| 11 | **Touch Targets** | All buttons ≥44×44px | Measure in dev tools |
| 12 | **Performance** | Single file <200KB, loads in <2s on 3G | Network panel |
| 13 | **Font Loading** | No FOIT; fonts swap gracefully | Throttle network |
| 14 | **Image Alt Text** | All images have meaningful alt (or alt="" if decorative) | HTML review |

---

# PHASE 6: DELIVER — Handoff Specifications

---

## 6.1 Deliverables

| Item | Description |
|------|-------------|
| **onestopnews-landing.html** | Complete single-file landing page |
| **Design rationale** | This document — the complete design plan |

## 6.2 Usage Instructions

1. Open `onestopnews-landing.html` directly in any modern browser
2. No server or build step required
3. Requires internet connection for Google Fonts, Tailwind CDN, and Lucide CDN
4. For offline use, download fonts and replace CDN links with local paths

## 6.3 Integration Path (Next Steps)

| Step | Action |
|------|--------|
| 1 | Convert to Next.js 16 App Router — Server Components for static sections, Client Components for interactive demo |
| 2 | Replace `picsum.photos` with actual article images from PostgreSQL |
| 3 | Wire category nav to actual `/topics/[category]` routes |
| 4 | Connect AI Summary Demo to real `/api/summarize/[id]` endpoint |
| 5 | Implement Shadcn UI primitives (Tabs, Accordion) wrapped in editorial aesthetic |
| 6 | Add Tailwind v4 `@theme` directives to `globals.css` |
| 7 | Add React 19.2 View Transitions for category switching |
| 8 | Implement mobile bottom navigation for thumb-friendly topic switching |

---

# APPENDIX: Design Decisions Log

---

| # | Decision | Rationale | Alternative Rejected |
|---|----------|-----------|---------------------|
| 1 | **"Ink & Signal" direction** | Higher contrast, more memorable, better analog/digital tension for news+AI product | Warm "Editorial Dispatch" (existing sample) — too soft, less distinctive |
| 2 | **Instrument Serif over Newsreader** | More distinctive editorial voice; better stroke contrast; superior italic forms; less commonly used | Newsreader — more conventional, less anti-generic |
| 3 | **Single HTML file deliverable** | Zero build tools; maximum portability; immediate browser preview; demonstrates that great design needs no complex toolchain | Next.js project — overkill for a mock landing page; adds build complexity |
| 4 | **Scroll-triggered reveals** | 2026 design trend (spatial design); purposeful motion serving comprehension; demonstrates attention to detail | No scroll animations — page feels flat and static |
| 5 | **Confidence bar animation** | Demonstrates AI transparency (core PRD requirement) in an engaging, visual way | Static percentage — less engaging, doesn't draw attention to transparency |
| 6 | **Deeper ink (#0A0A0A)** | Higher contrast against paper; more gravitas; "Ink & Signal" needs deep ink | #111111 — lighter, less dramatic contrast |
| 7 | **OKLCH color specification** | Perceptually uniform; better accessibility; future-proof for wider gamut displays | HSL/RGB — less perceptually accurate |
| 8 | **Wire ticker leads** | Sets "briefing room" tone instantly; signals operational seriousness; unique for landing pages | Traditional hero with value proposition — generic SaaS pattern |
| 9 | **Lead story IS the hero** | News readers want news, not marketing; shows the product immediately | CTA-first hero — forces users to read marketing before seeing value |
| 10 | **Asymmetric grid (7-5-4-4-4)** | Editorial feel; visual weight communicates importance; anti-generic | Symmetric bento — 2025-2026 AI design cliché |

---

*End of Design Plan — OneStopNews Landing Page*
*Ready for Phase 3 Validation*
